package com.bypratham.rfidreaderconnect.constants

internal const val BOOT_FIRMWARE: Byte = 0x04.toByte()
internal const val GET_VERSION: Byte = 0x03.toByte()
internal const val BOOT_BOOTLOADER: Byte = 0x09.toByte()
internal const val GET_SERIAL_NUMBER: Byte = 0x10.toByte()
internal const val SINGLE_TAG_INVENTORY: Byte = 0x21.toByte()
internal const val SYNCHRONOUS_INVENTORY: Byte = 0x22.toByte()
internal const val GET_TAG_BUFFER: Byte = 0x29.toByte()
internal const val ASYNCHRONOUS_INVENTORY: Byte = 0xAA.toByte()
internal const val WRITE_TAG_DATA: Byte = 0x24.toByte()
internal const val WRITE_TAG_EPC: Byte = 0x23.toByte()
internal const val LOCK_TAG: Byte = 0x25.toByte()
internal const val KILL_TAG: Byte = 0x26.toByte()
internal const val READ_TAG_DATA: Byte = 0x28.toByte()
internal const val SET_ANTENNA_PORTS: Byte = 0x91.toByte()
internal const val SET_CURRENT_TAG_PROTOCOL: Byte = 0x93.toByte()
internal const val SET_FREQUENCY_HOPPING: Byte = 0x95.toByte()
internal const val SET_GPO: Byte = 0x96.toByte()
internal const val SET_CURRENT_REGION: Byte = 0x97.toByte()
internal const val SET_READER_CONFIGURATION: Byte = 0x9A.toByte()
internal const val SET_PROTOCOL_CONFIGURATION: Byte = 0x9B.toByte()
internal const val GET_ANTENNA_PORTS: Byte = 0x61.toByte()
internal const val GET_TAG_PROTOCOL: Byte = 0x63.toByte()
internal const val GET_FREQUENCY_HOPPING: Byte = 0x65.toByte()
internal const val GET_GPI: Byte = 0x66.toByte()
internal const val GET_CURRENT_REGION: Byte = 0x67.toByte()
internal const val GET_AVAILABLE_REGIONS: Byte = 0x71.toByte()
internal const val GET_READER_CONFIGURATION: Byte = 0x6A.toByte()
internal const val GET_PROTOCOL_CONFIGURATION: Byte = 0x6B.toByte()
internal const val GET_CURRENT_TEMPERATURE: Byte = 0x72.toByte()

internal val commandCodeToName: Map<UByte, String> =
    mapOf(
        0x04u.toUByte() to "BOOT_FIRMWARE",
        0x03u.toUByte() to "GET_VERSION",
        0x09u.toUByte() to "BOOT_BOOTLOADER",
        0x10u.toUByte() to "GET_SERIAL_NUMBER",
        0x21u.toUByte() to "SINGLE_TAG_INVENTORY",
        0x22u.toUByte() to "SYNCHRONOUS_INVENTORY",
        0x29u.toUByte() to "GET_TAG_BUFFER",
        0xAAu.toUByte() to "ASYNCHRONOUS_INVENTORY",
        0x24u.toUByte() to "WRITE_TAG_DATA",
        0x23u.toUByte() to "WRITE_TAG_EPC",
        0x25u.toUByte() to "LOCK_TAG",
        0x26u.toUByte() to "KILL_TAG",
        0x28u.toUByte() to "READ_TAG_DATA",
        0x91u.toUByte() to "SET_ANTENNA_PORTS",
        0x93u.toUByte() to "SET_CURRENT_TAG_PROTOCOL",
        0x95u.toUByte() to "SET_FREQUENCY_HOPPING",
        0x96u.toUByte() to "SET_GPO",
        0x97u.toUByte() to "SET_CURRENT_REGION",
        0x9Au.toUByte() to "SET_READER_CONFIGURATION",
        0x9Bu.toUByte() to "SET_PROTOCOL_CONFIGURATION",
        0x61u.toUByte() to "GET_ANTENNA_PORTS",
        0x63u.toUByte() to "GET_TAG_PROTOCOL",
        0x65u.toUByte() to "GET_FREQUENCY_HOPPING",
        0x66u.toUByte() to "GET_GPI",
        0x67u.toUByte() to "GET_CURRENT_REGION",
        0x71u.toUByte() to "GET_AVAILABLE_REGIONS",
        0x6Au.toUByte() to "GET_READER_CONFIGURATION",
        0x6Bu.toUByte() to "GET_PROTOCOL_CONFIGURATION",
        0x72u.toUByte() to "GET_CURRENT_TEMPERATURE",
    )
