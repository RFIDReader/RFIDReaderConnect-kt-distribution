package com.bypratham.rfidreaderconnect.constants

/** Terminator byte required at the end of every "Moduletech" sub-command payload. */
internal const val MODULETECH_TERMINATOR: Byte = 0xBB.toByte()

/** ASCII "Moduletech" preamble used inside 0xFF/0xAA module frames. */
internal val MODULETECH_PREAMBLE: ByteArray =
    byteArrayOf(
        0x4D, 0x6F, 0x64, 0x75, 0x6C, 0x65, 0x74, 0x65, 0x63, 0x68,
    )

/** ASCII "XTSJ" heartbeat prefix used by the reader between asynchronous inventory frames. */
internal val HEARTBEAT_PREFIX: ByteArray = byteArrayOf(0x58, 0x54, 0x53, 0x4A)
