package com.bypratham.rfidreaderconnect

/**
 * Contract every `RFIDReader` implementation must satisfy. Mirrors the iOS
 * `RFIDReaderProtocol` 1:1 so applications can share integration logic
 * between platforms.
 */
interface RFIDReaderProtocol {
    /** Attempts to connect to the reader; observe [RFIDReaderDelegate.rfidReaderDidConnect]. */
    fun connect()

    /** Disconnects the reader; observe [RFIDReaderDelegate.rfidReaderDidDisconnect]. */
    fun disconnect()

    /** Get reader communication mode; result surfaces via `rfidReaderDidReceiveMessage`. */
    fun getCommMode()

    fun setCommMode(commMode: RFIDReaderCommMode)

    /** WiFi STA SSID; result key `network_ssid`. */
    fun getNetworkSSID()

    fun setNetworkSSID(ssid: String)

    /** WiFi STA password; result key `network_password`. */
    fun getNetworkPassword()

    fun setNetworkPassword(password: String)

    fun getAlertNotification()

    fun setAlertNotification(notificationType: RFIDReaderNotificationType)

    /** Firmware version block; result key `version`. */
    fun getVersion()

    /** Reader serial number; result key `serial_number`. */
    fun getSerialNumber()

    fun getDeviceName()

    fun getModel()

    fun setDeviceName(deviceName: String)

    fun getIPv4()

    fun getMac()

    fun getBatterySoc()

    fun getBatterySoh()

    fun getBatteryCycles()

    fun factoryReset()

    fun reboot()

    fun performOTA(version: String)

    fun sendRawCmd(
        cmd: ByteArray,
        calculateCRC: Boolean,
    )

    fun getHWVersion()

    fun getHWSerialNumber()

    fun bootFirmware()

    fun singleTagInventory(
        timeout: UShort,
        metadata: List<RFIDReaderTagMetadata>? = null,
        tagSingulationFlag: RFIDReaderTagSingulationFlag? = null,
        tagSingulationData: RFIDReaderTagSingulationData? = null,
    )

    /** Only valid over WiFi (REST). */
    fun startSyncInventory()

    fun getTagBuffer()

    fun startAsyncInventory(
        powerSave: Boolean? = null,
        metadata: List<RFIDReaderTagMetadata>? = null,
        password: RFIDTagPassword? = null,
        tsFlag: RFIDReaderTagSingulationFlag? = null,
        tsData: RFIDReaderTagSingulationData? = null,
        memoryBank: RFIDTagMemoryBank? = null,
        readAddress: RFIDTagMemoryAddress? = null,
        wordCount: UByte? = null,
    )

    fun stopAsyncInventory()

    /** Only supported by CN, CE, IN, RU, PH, JP, IL variants. */
    fun startEXAsyncInventory(metadata: List<RFIDReaderTagMetadata>? = null)

    fun stopEXAsyncInventory()

    fun writeTagEPC(
        tagEPC: ByteArray,
        timeout: UShort,
        password: RFIDTagPassword? = null,
        tagSingulationFlag: RFIDReaderTagSingulationFlag? = null,
        tagSingulationData: RFIDReaderTagSingulationData? = null,
    )

    fun writeTag(data: ByteArray)

    fun lockTag()

    fun killTag()

    fun readTagMemoryBank(
        timeout: UShort,
        tagSingulationFlag: RFIDReaderTagSingulationFlag? = null,
        metadata: List<RFIDReaderTagMetadata>? = null,
        memoryBank: RFIDTagMemoryBank,
        readAddress: RFIDTagMemoryAddress,
        wordCount: UByte,
        password: RFIDTagPassword? = null,
        tagSingulationData: RFIDReaderTagSingulationData? = null,
    ): RFIDTag?

    fun getAntennaPort()

    fun setAntennaPort(
        antennaPorts: List<RFIDReaderAntennaPort>,
        permanent: Boolean? = null,
    )

    fun getFreqHopping()

    fun setFreqHopping(region: RFIDReaderRegion)

    fun getRegion()

    fun setRegion(
        region: RFIDReaderRegion,
        permanent: Boolean? = null,
    )

    fun getTemperature()

    fun getReaderConfiguration(readerConfiguration: RFIDReaderConfiguration)

    fun setReaderConfiguration(
        readerConfiguration: RFIDReaderConfiguration,
        enable: Boolean,
    )

    fun getSession()

    fun setSession(
        session: RFIDReaderSession,
        permanent: Boolean? = null,
    )

    fun getTarget()

    fun setTarget(
        target: RFIDReaderTarget,
        permanent: Boolean? = null,
    )

    fun getRFMode()

    fun setRFMode(
        mode: RFIDReaderRFMode,
        permanent: Boolean? = null,
    )

    fun getQ()

    fun setQ(
        q: RFIDReaderQ?,
        permanent: Boolean? = null,
    )
}
