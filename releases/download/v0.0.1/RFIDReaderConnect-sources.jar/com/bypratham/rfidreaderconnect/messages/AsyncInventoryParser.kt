package com.bypratham.rfidreaderconnect.messages

import android.util.Log
import com.bypratham.rfidreaderconnect.RFIDReaderTagMetadata
import com.bypratham.rfidreaderconnect.RFIDTag
import com.bypratham.rfidreaderconnect.RFIDTagPhase
import com.bypratham.rfidreaderconnect.constants.HEARTBEAT_PREFIX
import com.bypratham.rfidreaderconnect.constants.MODULETECH_PREAMBLE
import com.bypratham.rfidreaderconnect.dataAsHex

/** Callback surface for [AsyncInventoryParser]. Mirrors iOS `AsyncInventoryParserDelegate`. */
internal interface AsyncInventoryParserDelegate {
    fun asyncInventoryParserDidReceiveStartAsyncInventory()

    fun asyncInventoryParserDidReadTag(tag: RFIDTag)

    fun asyncInventoryParserDidReceiveHearbeatPacket()

    fun asyncInventoryParserDidReceiveStopAsyncInventory()

    fun asyncInventoryParserDidEncounteredError(error: Throwable)
}

/**
 * Parses `0xFF 0xAA ...` frames the reader emits during asynchronous inventory.
 * Delivers one [RFIDTag] per tag response and dedicated callbacks for
 * heartbeat + start / stop sentinels.
 */
internal class AsyncInventoryParser(
    private val delegate: AsyncInventoryParserDelegate,
) {
    private val tag = "[ASYNCInventoryParser]"

    private fun ByteArray.u8(index: Int): Int = this[index].toInt() and 0xFF

    private fun ByteArray.u16(index: Int): Int = (u8(index) shl 8) or u8(index + 1)

    private fun ByteArray.startsWith(prefix: ByteArray): Boolean {
        if (this.size < prefix.size) return false
        for (i in prefix.indices) {
            if (this[i] != prefix[i]) return false
        }
        return true
    }

    fun parse(data: ByteArray) {
        val header = data.u8(0)
        var dataLen = data.u8(1)
        val cmd = data.u8(2)

        if (header == 0xFF && cmd == 0xAA) {
            val payloadLen = data.u8(1)
            if (payloadLen > data.size - 5 - 2) {
                Log.w(tag, "${dataAsHex(data)} invalid frame buffer dataLen=$payloadLen dataCount=${data.size - 5 - 2}")
                return
            }
            val frameData = data.copyOfRange(5, 5 + payloadLen)
            if (frameData.startsWith(HEARTBEAT_PREFIX)) {
                delegate.asyncInventoryParserDidReceiveHearbeatPacket()
                return
            } else if (frameData.startsWith(MODULETECH_PREAMBLE)) {
                val subCommand =
                    ((frameData.u8(payloadLen - 2) and 0xFF) shl 8) or (frameData.u8(payloadLen - 1) and 0xFF)
                if (subCommand == 0xAA48 || subCommand == 0xAA58) {
                    delegate.asyncInventoryParserDidReceiveStartAsyncInventory()
                    return
                } else if (subCommand == 0xAA49 || subCommand == 0xAA59) {
                    delegate.asyncInventoryParserDidReceiveStopAsyncInventory()
                    return
                }
            }
        }

        var metadata = data.u16(5)
        dataLen -= 2

        var idxPtr = 7
        var rssi: Int? = null
        var antennaID: UByte? = null
        var frequency: ByteArray? = null
        var timestamp: ByteArray? = null
        var phaseValue: RFIDTagPhase? = null
        var tagDataLen: UShort? = null

        if (metadata and RFIDReaderTagMetadata.RETURN_READ_COUNT.rawValue.toInt() > 0) {
            metadata = metadata and RFIDReaderTagMetadata.RETURN_READ_COUNT.rawValue.toInt().inv()
            idxPtr += 1
        }
        if (metadata and RFIDReaderTagMetadata.RETURN_RSSI.rawValue.toInt() > 0) {
            rssi = data[idxPtr].toInt() // sign-extends the raw byte, matching iOS Int8(bitPattern:)
            metadata = metadata and RFIDReaderTagMetadata.RETURN_RSSI.rawValue.toInt().inv()
            idxPtr += 1
        }
        if (metadata and RFIDReaderTagMetadata.RETURN_ANTENNA_ID.rawValue.toInt() > 0) {
            antennaID = data.u8(idxPtr).toUByte()
            metadata = metadata and RFIDReaderTagMetadata.RETURN_ANTENNA_ID.rawValue.toInt().inv()
            idxPtr += 1
        }
        if (metadata and RFIDReaderTagMetadata.RETURN_FREQUENCY.rawValue.toInt() > 0) {
            frequency = data.copyOfRange(idxPtr, idxPtr + 3)
            metadata = metadata and RFIDReaderTagMetadata.RETURN_FREQUENCY.rawValue.toInt().inv()
            idxPtr += 3
        }
        if (metadata and RFIDReaderTagMetadata.RETURN_TIMESTAMP.rawValue.toInt() > 0) {
            timestamp = data.copyOfRange(idxPtr, idxPtr + 4)
            metadata = metadata and RFIDReaderTagMetadata.RETURN_TIMESTAMP.rawValue.toInt().inv()
            idxPtr += 4
        }
        if (metadata and RFIDReaderTagMetadata.RETURN_PHASE_VALUE.rawValue.toInt() > 0) {
            phaseValue = RFIDTagPhase(data.u16(idxPtr).toUShort())
            metadata = metadata and RFIDReaderTagMetadata.RETURN_PHASE_VALUE.rawValue.toInt().inv()
            idxPtr += 2
        }
        if (metadata and RFIDReaderTagMetadata.RETURN_DATA_LEN.rawValue.toInt() > 0) {
            tagDataLen = data.u16(idxPtr).toUShort()
            metadata = metadata and RFIDReaderTagMetadata.RETURN_DATA_LEN.rawValue.toInt().inv()
            idxPtr += 2
        }

        if (metadata != 0) {
            Log.w(tag, "invalid metadata")
            return
        }

        val epcLen = data.u8(idxPtr)
        idxPtr += 1
        val pc = data.u16(idxPtr).toUShort()
        idxPtr += 2

        val tagData = data.copyOfRange(idxPtr, idxPtr + (epcLen - 4))
        delegate.asyncInventoryParserDidReadTag(
            RFIDTag(
                rssi = rssi,
                antennaID = antennaID,
                frequency = frequency,
                timestamp = timestamp,
                phase = phaseValue,
                tagDataLen = tagDataLen,
                epcLen = tagData.size.toUByte(),
                pc = pc,
                epc = tagData,
            ),
        )
    }
}
