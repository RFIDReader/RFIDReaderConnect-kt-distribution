package com.bypratham.rfidreaderconnect.messages

import com.bypratham.rfidreaderconnect.RFIDReaderAntennaPort
import com.bypratham.rfidreaderconnect.RFIDReaderCommMode
import com.bypratham.rfidreaderconnect.RFIDReaderConfiguration
import com.bypratham.rfidreaderconnect.RFIDReaderNotificationType
import com.bypratham.rfidreaderconnect.RFIDReaderQ
import com.bypratham.rfidreaderconnect.RFIDReaderRFMode
import com.bypratham.rfidreaderconnect.RFIDReaderRegion
import com.bypratham.rfidreaderconnect.RFIDReaderSerialNumber
import com.bypratham.rfidreaderconnect.RFIDReaderSession
import com.bypratham.rfidreaderconnect.RFIDReaderTagMetadata
import com.bypratham.rfidreaderconnect.RFIDReaderTarget
import com.bypratham.rfidreaderconnect.RFIDReaderVersion
import com.bypratham.rfidreaderconnect.RFIDTag
import com.bypratham.rfidreaderconnect.RFIDTagPhase
import com.bypratham.rfidreaderconnect.constants.BOOT_FIRMWARE
import com.bypratham.rfidreaderconnect.constants.GET_ANTENNA_PORTS
import com.bypratham.rfidreaderconnect.constants.GET_CURRENT_REGION
import com.bypratham.rfidreaderconnect.constants.GET_CURRENT_TEMPERATURE
import com.bypratham.rfidreaderconnect.constants.GET_FREQUENCY_HOPPING
import com.bypratham.rfidreaderconnect.constants.GET_PROTOCOL_CONFIGURATION
import com.bypratham.rfidreaderconnect.constants.GET_READER_CONFIGURATION
import com.bypratham.rfidreaderconnect.constants.GET_SERIAL_NUMBER
import com.bypratham.rfidreaderconnect.constants.GET_VERSION
import com.bypratham.rfidreaderconnect.constants.SET_ANTENNA_PORTS
import com.bypratham.rfidreaderconnect.constants.SET_CURRENT_REGION
import com.bypratham.rfidreaderconnect.constants.SET_FREQUENCY_HOPPING
import com.bypratham.rfidreaderconnect.constants.SET_PROTOCOL_CONFIGURATION
import com.bypratham.rfidreaderconnect.constants.SET_READER_CONFIGURATION
import com.bypratham.rfidreaderconnect.constants.SINGLE_TAG_INVENTORY
import com.bypratham.rfidreaderconnect.constants.WRITE_TAG_EPC

/**
 * Response-frame parsers. Ported from iOS `MessageParser.swift`. Each parser
 * accepts a full validated frame (including CRC bytes) and returns a typed
 * result to be forwarded to [com.bypratham.rfidreaderconnect.RFIDReaderDelegate.rfidReaderDidReceiveMessage].
 */

private fun ByteArray.u8(index: Int): Int = this[index].toInt() and 0xFF

private fun ByteArray.u16(index: Int): Int = (u8(index) shl 8) or u8(index + 1)

internal fun parseCommMode(data: ByteArray): RFIDReaderCommMode? = RFIDReaderCommMode.fromRaw(data.u8(5).toUByte())

internal fun parseTime(
    @Suppress("UNUSED_PARAMETER") data: ByteArray,
): Map<String, Any?> = mapOf("time" to null)

internal fun parseNetworkSSID(data: ByteArray): Map<String, String?> {
    val len = data.u8(1)
    val value = data.copyOfRange(5, 5 + len)
    return mapOf("network_ssid" to value.toString(Charsets.UTF_8))
}

internal fun parseNetworkPassword(data: ByteArray): Map<String, String?> {
    val len = data.u8(1)
    val value = data.copyOfRange(5, 5 + len)
    return mapOf("network_password" to value.toString(Charsets.UTF_8))
}

internal fun parseNotificationType(data: ByteArray): RFIDReaderNotificationType? =
    RFIDReaderNotificationType.fromRaw(data.u8(5).toUByte())

internal fun parseDeviceName(data: ByteArray): Map<String, String?> {
    val len = data.u8(1)
    val value = data.copyOfRange(5, 5 + len)
    return mapOf("name" to value.toString(Charsets.UTF_8))
}

internal fun parseIPv4(data: ByteArray): Map<String, String?> =
    if (data.size > 8) {
        mapOf("ipv4" to "${data.u8(5)}:${data.u8(6)}:${data.u8(7)}:${data.u8(8)}")
    } else {
        mapOf("ipv4" to "-")
    }

internal fun parseMac(data: ByteArray): Map<String, String?> =
    mapOf(
        "mac" to
            "%02X:%02X:%02X:%02X:%02X:%02X".format(
                data.u8(5),
                data.u8(6),
                data.u8(7),
                data.u8(8),
                data.u8(9),
                data.u8(10),
            ),
    )

internal fun parseBatterySoc(data: ByteArray): Map<String, UByte?> = mapOf("soc" to data.u8(5).toUByte())

internal fun parseBatterySoh(data: ByteArray): Map<String, UByte?> = mapOf("soh" to data.u8(5).toUByte())

internal fun parseBatteryCycles(data: ByteArray): Map<String, UByte?> = mapOf("cycles" to data.u8(5).toUByte())

internal val messageParser: Map<UByte, (ByteArray) -> Any?> =
    mapOf(
        0x01u.toUByte() to ::parseCommMode,
        0x02u.toUByte() to ::parseTime,
        0x03u.toUByte() to ::parseNetworkSSID,
        0x04u.toUByte() to ::parseNetworkPassword,
        0x05u.toUByte() to ::parseNotificationType,
        0x08u.toUByte() to ::parseDeviceName,
        0xA1u.toUByte() to ::parseIPv4,
        0xA2u.toUByte() to ::parseMac,
        0xBAu.toUByte() to ::parseBatterySoc,
        0xBBu.toUByte() to ::parseBatterySoh,
        0xBCu.toUByte() to ::parseBatteryCycles,
    )

internal fun parseVersion(data: ByteArray): RFIDReaderVersion =
    RFIDReaderVersion(
        bootloaderVersion = data.copyOfRange(5, 9),
        hardwareVersion = data.copyOfRange(9, 13),
        firmwareDate = data.copyOfRange(13, 17),
        firmwareVersion = data.copyOfRange(17, 21),
    )

internal fun parseSerialNumber(data: ByteArray): RFIDReaderSerialNumber =
    RFIDReaderSerialNumber(
        year = data.copyOfRange(5, 9),
        serialNumber = data.copyOfRange(9, 17),
    )

@Suppress("UNUSED_PARAMETER")
internal fun parseSetAntennaPortsRes(data: ByteArray): Any? = null

@Suppress("UNUSED_PARAMETER")
internal fun parseSetFreqHoppingRes(data: ByteArray): Any? = null

@Suppress("UNUSED_PARAMETER")
internal fun parseSetRegionRes(data: ByteArray): Any? = null

@Suppress("UNUSED_PARAMETER")
internal fun parseSetReaderConfigRes(data: ByteArray): Any? = null

@Suppress("UNUSED_PARAMETER")
internal fun parseSetProtocolConfigRes(data: ByteArray): Any? = null

@Suppress("UNUSED_PARAMETER")
internal fun parseFreqHopping(data: ByteArray): Any? = null

internal fun parseRegion(data: ByteArray): RFIDReaderRegion? = RFIDReaderRegion.fromRaw(data.u8(5).toUByte())

internal fun parseReaderConfig(data: ByteArray): Pair<RFIDReaderConfiguration?, Boolean> {
    val key = data.u8(6).toUByte()
    val value = data.u8(7)
    return Pair(RFIDReaderConfiguration.fromRaw(key), value == 0x01)
}

internal fun parseAntennaPorts(data: ByteArray): List<RFIDReaderAntennaPort> {
    val dataLen = data.u8(1)
    val payloadSize = dataLen - 1
    require(payloadSize % 5 == 0) { "parseAntennaPorts: invalid payload" }
    val ports = mutableListOf<RFIDReaderAntennaPort>()
    var offset = 6
    val end = 6 + payloadSize
    while (offset + 5 <= end) {
        val number = data.u8(offset).toUByte()
        val readPower = ((data.u8(offset + 1) shl 8) or data.u8(offset + 2)).toUShort()
        val writePower = ((data.u8(offset + 3) shl 8) or data.u8(offset + 4)).toUShort()
        ports += RFIDReaderAntennaPort(number, readPower, writePower)
        offset += 5
    }
    return ports
}

internal fun parseProtocolConfig(data: ByteArray): Any? {
    val parameter = data.u8(6)
    return when (parameter) {
        0x00 -> RFIDReaderSession.fromRaw(data.u8(7).toUByte())
        0x01 -> {
            val option = data.u8(7)
            val value = data.u8(8)
            when (option) {
                0x01 -> if (value == 0x00) RFIDReaderTarget.A else RFIDReaderTarget.B
                0x00 -> if (value == 0x00) RFIDReaderTarget.AB else RFIDReaderTarget.BA
                else -> null
            }
        }
        0x02 -> RFIDReaderRFMode.fromRaw(data.u8(7).toUByte())
        0x12 -> {
            val option = data.u8(7)
            if (option == 0x00) RFIDReaderQ.DynamicQ else RFIDReaderQ.StaticQ(data.u8(8).toUByte())
        }
        else -> null
    }
}

internal fun parseSingleTag(data: ByteArray): Any? {
    val option = data.u8(5)
    if (option == 0x00) {
        val count = data.size
        val tagData = data.copyOfRange(6, count - 4)
        return RFIDTag(
            rssi = null,
            antennaID = null,
            frequency = null,
            timestamp = null,
            phase = null,
            tagDataLen = null,
            epcLen = tagData.size.toUByte(),
            pc = null,
            epc = tagData,
        )
    }
    val metadata = data.u16(6)
    var idxPtr = 8
    var rssi: Int? = null
    var antennaID: UByte? = null
    var frequency: ByteArray? = null
    var timestamp: ByteArray? = null
    var phaseValue: RFIDTagPhase? = null
    var dataLen: UShort? = null

    if (metadata and RFIDReaderTagMetadata.RETURN_READ_COUNT.rawValue.toInt() > 0) {
        idxPtr += 1
    }
    if (metadata and RFIDReaderTagMetadata.RETURN_RSSI.rawValue.toInt() > 0) {
        rssi = data[idxPtr].toInt() // sign-extends the raw byte, matching iOS Int8(bitPattern:)
        idxPtr += 1
    }
    if (metadata and RFIDReaderTagMetadata.RETURN_ANTENNA_ID.rawValue.toInt() > 0) {
        antennaID = data.u8(idxPtr).toUByte()
        idxPtr += 1
    }
    if (metadata and RFIDReaderTagMetadata.RETURN_FREQUENCY.rawValue.toInt() > 0) {
        frequency = data.copyOfRange(idxPtr, idxPtr + 3)
        idxPtr += 3
    }
    if (metadata and RFIDReaderTagMetadata.RETURN_TIMESTAMP.rawValue.toInt() > 0) {
        timestamp = data.copyOfRange(idxPtr, idxPtr + 4)
        idxPtr += 4
    }
    if (metadata and RFIDReaderTagMetadata.RETURN_PHASE_VALUE.rawValue.toInt() > 0) {
        phaseValue = RFIDTagPhase(data.u16(idxPtr).toUShort())
        idxPtr += 2
    }
    if (metadata and RFIDReaderTagMetadata.RETURN_DATA_LEN.rawValue.toInt() > 0) {
        dataLen = data.u16(idxPtr).toUShort()
        idxPtr += 2
    }
    val tagData = data.copyOfRange(idxPtr, data.size - 4)
    return RFIDTag(
        rssi = rssi,
        antennaID = antennaID,
        frequency = frequency,
        timestamp = timestamp,
        phase = phaseValue,
        tagDataLen = dataLen,
        epcLen = tagData.size.toUByte(),
        pc = null,
        epc = tagData,
    )
}

@Suppress("UNUSED_PARAMETER")
internal fun parseWriteTagRes(data: ByteArray): Boolean? = false

internal fun parseTemperature(data: ByteArray): Map<String, Int?> = mapOf("temperature" to data.u8(5))

internal val moduleMessageParser: Map<UByte, (ByteArray) -> Any?> =
    mapOf(
        GET_VERSION.toUByte() to ::parseVersion,
        BOOT_FIRMWARE.toUByte() to ::parseVersion,
        GET_SERIAL_NUMBER.toUByte() to ::parseSerialNumber,
        SET_ANTENNA_PORTS.toUByte() to ::parseSetAntennaPortsRes,
        SET_FREQUENCY_HOPPING.toUByte() to ::parseSetFreqHoppingRes,
        SET_CURRENT_REGION.toUByte() to ::parseSetRegionRes,
        SET_READER_CONFIGURATION.toUByte() to ::parseSetReaderConfigRes,
        SET_PROTOCOL_CONFIGURATION.toUByte() to ::parseSetProtocolConfigRes,
        GET_ANTENNA_PORTS.toUByte() to ::parseAntennaPorts,
        GET_FREQUENCY_HOPPING.toUByte() to ::parseFreqHopping,
        GET_CURRENT_REGION.toUByte() to ::parseRegion,
        GET_READER_CONFIGURATION.toUByte() to ::parseReaderConfig,
        GET_PROTOCOL_CONFIGURATION.toUByte() to ::parseProtocolConfig,
        SINGLE_TAG_INVENTORY.toUByte() to ::parseSingleTag,
        WRITE_TAG_EPC.toUByte() to ::parseWriteTagRes,
        GET_CURRENT_TEMPERATURE.toUByte() to ::parseTemperature,
    )
