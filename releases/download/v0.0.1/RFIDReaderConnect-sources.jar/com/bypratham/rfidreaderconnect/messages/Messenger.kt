package com.bypratham.rfidreaderconnect.messages

import com.bypratham.rfidreaderconnect.RFIDReaderAntennaPort
import com.bypratham.rfidreaderconnect.RFIDReaderBaudRate
import com.bypratham.rfidreaderconnect.RFIDReaderCommMode
import com.bypratham.rfidreaderconnect.RFIDReaderConfiguration
import com.bypratham.rfidreaderconnect.RFIDReaderNotificationType
import com.bypratham.rfidreaderconnect.RFIDReaderQ
import com.bypratham.rfidreaderconnect.RFIDReaderRFMode
import com.bypratham.rfidreaderconnect.RFIDReaderRegion
import com.bypratham.rfidreaderconnect.RFIDReaderSession
import com.bypratham.rfidreaderconnect.RFIDReaderTagMetadata
import com.bypratham.rfidreaderconnect.RFIDReaderTagSingulationData
import com.bypratham.rfidreaderconnect.RFIDReaderTagSingulationFlag
import com.bypratham.rfidreaderconnect.RFIDReaderTarget
import com.bypratham.rfidreaderconnect.RFIDTagMemoryAddress
import com.bypratham.rfidreaderconnect.RFIDTagMemoryBank
import com.bypratham.rfidreaderconnect.RFIDTagPassword
import com.bypratham.rfidreaderconnect.calcCRC
import com.bypratham.rfidreaderconnect.constants.HEARTBEAT_PREFIX
import com.bypratham.rfidreaderconnect.constants.MODULETECH_PREAMBLE
import com.bypratham.rfidreaderconnect.constants.MODULETECH_TERMINATOR
import com.bypratham.rfidreaderconnect.getSubCRC
import com.bypratham.rfidreaderconnect.int2Bytes

/**
 * Frame builders for every reader / module command. Ported 1:1 from iOS
 * `Messenger.swift`. Every builder returns a fully framed [ByteArray] ready to
 * hand to the transport layer.
 *
 * Frame layout for reader commands: `[Header 1B][DataLen 1B][CommandCode 1B][Data nB]`.
 * Module frames additionally include a trailing CRC16.
 */
internal object Messenger {
    val getCommMode: ByteArray = byteArrayOf(0x00, 0x00, 0x01)

    fun setCommMode(commMode: RFIDReaderCommMode): ByteArray = byteArrayOf(0x00, 0x01, 0x01, commMode.rawValue.toByte())

    val getTime: ByteArray = byteArrayOf(0x00, 0x00, 0x02)

    val getNetworkSSID: ByteArray = byteArrayOf(0x00, 0x00, 0x03)

    fun setNetworkSSID(ssid: String): ByteArray {
        require(ssid.length <= 31) { "SSID cannot be greater than 31 characters" }
        val bytes = ssid.toByteArray(Charsets.UTF_8)
        return byteArrayOf(0x00, bytes.size.toByte(), 0x03) + bytes
    }

    val getNetworkPassword: ByteArray = byteArrayOf(0x00, 0x00, 0x04)

    fun setNetworkPassword(password: String): ByteArray {
        require(password.length <= 64) { "PASSWORD cannot be greater than 64 characters" }
        val bytes = password.toByteArray(Charsets.UTF_8)
        return byteArrayOf(0x00, bytes.size.toByte(), 0x04) + bytes
    }

    val getAlertNotificationType: ByteArray = byteArrayOf(0x00, 0x00, 0x05)

    fun setAlertNotificationType(notificationType: RFIDReaderNotificationType): ByteArray =
        byteArrayOf(0x00, 0x01, 0x05, notificationType.rawValue.toByte())

    val getVersion: ByteArray = byteArrayOf(0x00, 0x00, 0x06)
    val getSerialNumber: ByteArray = byteArrayOf(0x00, 0x00, 0x07)
    val getDeviceName: ByteArray = byteArrayOf(0x00, 0x00, 0x08)

    fun setDeviceName(deviceName: String): ByteArray {
        require(deviceName.length <= 31) { "deviceName cannot be greater than 31 characters" }
        val bytes = deviceName.toByteArray(Charsets.UTF_8)
        return byteArrayOf(0x00, bytes.size.toByte(), 0x08) + bytes
    }

    val getModel: ByteArray = byteArrayOf(0x00, 0x00, 0x09)
    val getIPv4: ByteArray = byteArrayOf(0x00, 0x00, 0xA1.toByte())
    val getMac: ByteArray = byteArrayOf(0x00, 0x00, 0xA2.toByte())
    val getBatterySoc: ByteArray = byteArrayOf(0x00, 0x00, 0xBA.toByte())
    val getBatterySoh: ByteArray = byteArrayOf(0x00, 0x00, 0xBB.toByte())
    val getBatteryCycles: ByteArray = byteArrayOf(0x00, 0x00, 0xBC.toByte())

    fun setBaudRate(baudRate: RFIDReaderBaudRate): ByteArray {
        val dataLen: Byte = 0x14
        val prefix = byteArrayOf(0xFF.toByte(), dataLen) + moduletechHeader()
        val subCommand =
            byteArrayOf(0xAA.toByte(), 0x40, 0x06, 0x01) + int2Bytes(baudRate.rawValue, 4)
        val subCrc = getSubCRC(subCommand).toByte()
        val body = prefix + subCommand + byteArrayOf(subCrc, MODULETECH_TERMINATOR)
        return body + int2Bytes(calcCRC(body), 2)
    }

    val performFactoryReset: ByteArray = byteArrayOf(0x00, 0x00, 0xFD.toByte())
    val performReboot: ByteArray = byteArrayOf(0x00, 0x00, 0xFE.toByte())

    fun performOTA(version: String): ByteArray {
        val versionData = version.toByteArray(Charsets.UTF_8)
        return byteArrayOf(0x00, versionData.size.toByte(), 0xFF.toByte()) + versionData
    }

    // region Streaming OTA (transport-agnostic BLE / USB)
    // See rfid_reader_mark3/main/ota/stream_ota.h for the wire protocol.
    const val STREAMING_OTA_CMD_BEGIN: Int = 0xF0
    const val STREAMING_OTA_CMD_DATA: Int = 0xF1
    const val STREAMING_OTA_CMD_END: Int = 0xF2
    const val STREAMING_OTA_CMD_ABORT: Int = 0xF3

    /** `[0x00][data_len][0xF0][size:u32 LE][sha256:32B][version...]`. */
    fun streamingOTABegin(
        imageSize: UInt,
        sha256: ByteArray,
        version: String,
    ): ByteArray {
        require(sha256.size == 32) { "sha256 must be 32 bytes" }
        val versionData = version.toByteArray(Charsets.UTF_8)
        val dataLength = 4 + sha256.size + versionData.size
        require(dataLength <= 255) { "BEGIN payload too large; shorten the version tag" }
        return byteArrayOf(
            0x00,
            dataLength.toByte(),
            STREAMING_OTA_CMD_BEGIN.toByte(),
            (imageSize and 0xFFu).toByte(),
            ((imageSize shr 8) and 0xFFu).toByte(),
            ((imageSize shr 16) and 0xFFu).toByte(),
            ((imageSize shr 24) and 0xFFu).toByte(),
        ) + sha256 + versionData
    }

    /** `[0x00][0x00][0xF1][chunk_len:u16 LE][seq:u16 LE][chunk...]`. */
    fun streamingOTAData(
        seq: UShort,
        chunk: ByteArray,
    ): ByteArray {
        require(chunk.size <= UShort.MAX_VALUE.toInt()) { "OTA chunk cannot exceed 65535 bytes" }
        val chunkLength = chunk.size
        return byteArrayOf(
            0x00,
            0x00,
            STREAMING_OTA_CMD_DATA.toByte(),
            (chunkLength and 0xFF).toByte(),
            ((chunkLength shr 8) and 0xFF).toByte(),
            (seq.toInt() and 0xFF).toByte(),
            ((seq.toInt() shr 8) and 0xFF).toByte(),
        ) + chunk
    }

    val streamingOTAEnd: ByteArray = byteArrayOf(0x00, 0x00, STREAMING_OTA_CMD_END.toByte())
    val streamingOTAAbort: ByteArray = byteArrayOf(0x00, 0x00, STREAMING_OTA_CMD_ABORT.toByte())
    // endregion

    fun sendRawCmd(
        cmd: ByteArray,
        @Suppress("UNUSED_PARAMETER") calculateCRC: Boolean = true,
    ): ByteArray = cmd + int2Bytes(calcCRC(cmd), 2)

    fun getHWVersion(): ByteArray {
        val data = byteArrayOf(0xFF.toByte(), 0x00, 0x03)
        return data + int2Bytes(calcCRC(data), 2)
    }

    fun getHWSerialNumber(): ByteArray {
        val data = byteArrayOf(0xFF.toByte(), 0x02, 0x10, 0x00, 0x00)
        return data + int2Bytes(calcCRC(data), 2)
    }

    fun bootFirmware(): ByteArray {
        val data = byteArrayOf(0xFF.toByte(), 0x00, 0x04)
        return data + int2Bytes(calcCRC(data), 2)
    }

    fun getRegion(): ByteArray {
        val data = byteArrayOf(0xFF.toByte(), 0x00, 0x67)
        return data + int2Bytes(calcCRC(data), 2)
    }

    fun setRegion(region: RFIDReaderRegion): ByteArray {
        val data = byteArrayOf(0xFF.toByte(), 0x01, 0x97.toByte(), region.rawValue.toByte())
        return data + int2Bytes(calcCRC(data), 2)
    }

    fun getFreqHopping(): ByteArray {
        val data = byteArrayOf(0xFF.toByte(), 0x00, 0x65)
        return data + int2Bytes(calcCRC(data), 2)
    }

    fun setFreqHopping(frequencies: IntArray): ByteArray {
        if (frequencies.isEmpty()) return ByteArray(0)
        val head = byteArrayOf(0xFF.toByte(), (frequencies.size * 4).toByte(), 0x95.toByte())
        val body = frequencies.fold(head) { acc, freq -> acc + int2Bytes(freq, 4) }
        return body + int2Bytes(calcCRC(body), 2)
    }

    fun getAntennaPorts(): ByteArray {
        val data = byteArrayOf(0xFF.toByte(), 0x01, 0x61, 0x03)
        return data + int2Bytes(calcCRC(data), 2)
    }

    fun setAntennaPorts(antennaPorts: List<RFIDReaderAntennaPort>): ByteArray {
        var dataLen: Int = 0x01
        var body = byteArrayOf(0xFF.toByte(), 0x00, 0x91.toByte(), 0x03)
        for (port in antennaPorts) {
            dataLen += 5
            body =
                body +
                byteArrayOf(port.number.toByte()) +
                int2Bytes(port.readPower, 2) +
                int2Bytes(port.writePower, 2)
        }
        body[1] = dataLen.toByte()
        return body + int2Bytes(calcCRC(body), 2)
    }

    fun writeTagEPC(
        tagEPC: ByteArray,
        timeout: UShort,
        password: RFIDTagPassword? = null,
        tsFlag: RFIDReaderTagSingulationFlag? = null,
        tsData: RFIDReaderTagSingulationData? = null,
    ): ByteArray {
        var dataLen: Int = 0x02
        var body = byteArrayOf(0xFF.toByte(), 0x00, 0x23) + int2Bytes(timeout, 2)

        var option: Int = 0x00
        if (tsFlag != null && tsData != null) option = option xor tsFlag.rawValue.toInt()

        dataLen += 1
        body = body + byteArrayOf(option.toByte())

        if (option == 0x00) {
            dataLen += 1
            body = body + byteArrayOf(0x00)
        } else {
            dataLen += 4
            body = body + int2Bytes(password ?: 0u, 4)
            tsData?.selectAddress?.let {
                dataLen += 4
                body = body + it
            }
            tsData?.let { data ->
                if (data.selectDataLength.isNotEmpty()) {
                    dataLen += data.selectDataLength.size
                    body = body + data.selectDataLength
                    dataLen += data.selectData.size
                    body = body + data.selectData
                }
            }
        }

        dataLen += tagEPC.size
        body = body + tagEPC
        body[1] = dataLen.toByte()
        return body + int2Bytes(calcCRC(body), 2)
    }

    fun writeTag(
        timeout: UShort,
        writeReadFlag: Boolean? = false,
        tsFlag: RFIDReaderTagSingulationFlag? = null,
        writeAddress: RFIDTagMemoryAddress,
        writeMemoryBank: RFIDTagMemoryBank,
        password: RFIDTagPassword? = null,
        tsData: RFIDReaderTagSingulationData? = null,
        writeData: ByteArray,
        readBank: RFIDTagMemoryBank? = null,
        readAddress: RFIDTagMemoryAddress? = null,
        readLength: UByte? = null,
    ): ByteArray {
        if (writeReadFlag == true &&
            (readBank == null || readAddress == null || readLength == null)
        ) {
            return ByteArray(0)
        }

        var dataLen: Int = 0x02
        var body = byteArrayOf(0xFF.toByte(), 0x00, 0x24) + int2Bytes(timeout, 2)

        if (writeReadFlag == true) {
            body = body + byteArrayOf(0x84.toByte())
            dataLen += 1
        }
        val option: Int = (tsFlag ?: RFIDReaderTagSingulationFlag.NONE).rawValue.toInt()
        body = body + byteArrayOf(option.toByte())
        dataLen += 1

        body =
            body +
            int2Bytes(writeAddress, 4) +
            byteArrayOf(writeMemoryBank.rawValue.toByte())
        dataLen += 5

        if (option != 0x00) {
            body = body + int2Bytes(password ?: 0u, 4)
            dataLen += 4
        }
        tsData?.selectAddress?.let {
            dataLen += 4
            body = body + it
        }
        tsData?.let { data ->
            if (data.selectDataLength.isNotEmpty()) {
                dataLen += data.selectDataLength.size
                body = body + data.selectDataLength
                dataLen += data.selectData.size
                body = body + data.selectData
            }
        }
        body = body + writeData
        dataLen += writeData.size

        if (writeReadFlag == true) {
            body =
                body +
                byteArrayOf(readBank!!.rawValue.toByte()) +
                int2Bytes(readAddress!!, 4) +
                byteArrayOf(readLength!!.toByte())
            dataLen += 6
        }

        body[1] = dataLen.toByte()
        return body + int2Bytes(calcCRC(body), 2)
    }

    fun readTagMemoryBank(
        timeout: UShort,
        tsFlag: RFIDReaderTagSingulationFlag? = null,
        metadata: List<RFIDReaderTagMetadata>? = null,
        memoryBank: RFIDTagMemoryBank,
        readAddress: RFIDTagMemoryAddress,
        wordCount: UByte,
        password: RFIDTagPassword? = null,
        tsData: RFIDReaderTagSingulationData? = null,
    ): ByteArray {
        var dataLen: Int = 0x03
        val option: Int = (tsFlag ?: RFIDReaderTagSingulationFlag.NONE).rawValue.toInt()
        var body = byteArrayOf(0xFF.toByte(), 0x00, 0x28) + int2Bytes(timeout, 2) + byteArrayOf(option.toByte())

        if (option == 0x01) {
            var metadataXOR: Int = 0
            metadata?.forEach { metadataXOR = metadataXOR xor it.rawValue.toInt() }
            body = body + int2Bytes(metadataXOR.toLong() and 0xFFFF, 2)
            dataLen += 2
        }
        body =
            body +
            byteArrayOf(memoryBank.rawValue.toByte()) +
            int2Bytes(readAddress, 4) +
            byteArrayOf(wordCount.toByte())
        dataLen += 6

        if (option != 0x00) {
            body = body + int2Bytes(password ?: 0u, 4)
            dataLen += 4
        }
        tsData?.selectAddress?.let {
            dataLen += 4
            body = body + it
        }
        tsData?.let { data ->
            if (data.selectDataLength.isNotEmpty()) {
                dataLen += data.selectDataLength.size
                body = body + data.selectDataLength
                dataLen += data.selectData.size
                body = body + data.selectData
            }
        }

        body[1] = dataLen.toByte()
        return body + int2Bytes(calcCRC(body), 2)
    }

    fun singleTagInventory(
        timeout: UShort,
        metadata: List<RFIDReaderTagMetadata>? = null,
        tsFlag: RFIDReaderTagSingulationFlag? = null,
        tsData: RFIDReaderTagSingulationData? = null,
    ): ByteArray {
        var dataLen: Int = 0x03
        var option: Int = 0x00
        var body = byteArrayOf(0xFF.toByte(), 0x00, 0x21) + int2Bytes(timeout, 2)

        var metadataXOR: Int = 0
        if (metadata != null) {
            option = option xor 0x10
            metadata.forEach { metadataXOR = metadataXOR xor it.rawValue.toInt() }
        }
        if (tsFlag != null && tsData != null) {
            when (tsFlag) {
                RFIDReaderTagSingulationFlag.FILTER_EPC -> {
                    require(tsData.selectDataLength.isNotEmpty()) {
                        "FILTER_EPC requires selectDataLength & selectData"
                    }
                }
                else -> error("unhandled tag singulation flag ($tsFlag) for singleTagInventory")
            }
            option = option xor tsFlag.rawValue.toInt()
        }

        body = body + byteArrayOf(option.toByte())
        if (metadata != null) {
            dataLen += 2
            body = body + int2Bytes(metadataXOR.toLong() and 0xFFFF, 2)
        }
        tsData?.selectAddress?.let {
            dataLen += 4
            body = body + it
        }
        tsData?.let { data ->
            if (data.selectDataLength.isNotEmpty()) {
                dataLen += data.selectDataLength.size
                body = body + data.selectDataLength
                dataLen += data.selectData.size
                body = body + data.selectData
            }
        }
        body[1] = dataLen.toByte()
        return body + int2Bytes(calcCRC(body), 2)
    }

    fun startAsyncInventory(
        powerSave: Boolean? = null,
        metadata: List<RFIDReaderTagMetadata>? = null,
        password: RFIDTagPassword? = null,
        tsFlag: RFIDReaderTagSingulationFlag? = null,
        tsData: RFIDReaderTagSingulationData? = null,
        memoryBank: RFIDTagMemoryBank? = null,
        readAddress: RFIDTagMemoryAddress? = null,
        wordCount: UByte? = null,
    ): ByteArray {
        var metadataXOR: Int = 0
        metadata?.forEach { metadataXOR = metadataXOR xor it.rawValue.toInt() }

        val option: Int = (tsFlag ?: RFIDReaderTagSingulationFlag.NONE).rawValue.toInt()

        var searchFlagHighByte: Int = 0
        searchFlagHighByte = searchFlagHighByte or (1 shl 7)
        if (powerSave == true) searchFlagHighByte = searchFlagHighByte or (1 shl 6)

        var searchFlagLowByte: Int = 0
        searchFlagLowByte = searchFlagLowByte or (1 shl 0)
        searchFlagLowByte = searchFlagLowByte or (1 shl 1)
        if (memoryBank != null) searchFlagLowByte = searchFlagLowByte or (1 shl 2)

        var dataLen: Int = 0x0A
        var body = byteArrayOf(0xFF.toByte(), dataLen.toByte()) + moduletechHeader()

        var subCommand =
            byteArrayOf(0xAA.toByte(), 0x48) +
                int2Bytes(metadataXOR.toLong() and 0xFFFF, 2) +
                byteArrayOf(option.toByte(), searchFlagHighByte.toByte(), searchFlagLowByte.toByte())

        if (option != 0x00) {
            subCommand = subCommand + int2Bytes(password ?: 0u, 4)
        }
        tsData?.selectAddress?.let { subCommand = subCommand + it }
        tsData?.let { data ->
            if (data.selectDataLength.isNotEmpty()) {
                subCommand = subCommand + data.selectDataLength
                subCommand = subCommand + data.selectData
            }
        }

        var embeddedCommand = ByteArray(0)
        if (memoryBank != null) {
            embeddedCommand =
                embeddedCommand +
                byteArrayOf(0x01, 0x09, 0x28, 0x00, 0x00, 0x00, memoryBank.rawValue.toByte()) +
                int2Bytes(readAddress ?: 0u, 4) +
                byteArrayOf((wordCount ?: 0x01u).toByte())
        }
        subCommand = subCommand + embeddedCommand

        val subCrc = getSubCRC(subCommand).toByte()
        body = body + subCommand
        dataLen += subCommand.size
        body = body + byteArrayOf(subCrc, MODULETECH_TERMINATOR)
        dataLen += 2

        body[1] = dataLen.toByte()
        return body + int2Bytes(calcCRC(body), 2)
    }

    fun stopAsyncInventory(): ByteArray {
        val subCommand = byteArrayOf(0xAA.toByte(), 0x49)
        val subCrc = getSubCRC(subCommand).toByte()
        val dataLen: Byte = 0x0E
        val body =
            byteArrayOf(0xFF.toByte(), dataLen) +
                moduletechHeader() +
                subCommand +
                byteArrayOf(subCrc, MODULETECH_TERMINATOR)
        return body + int2Bytes(calcCRC(body), 2)
    }

    fun startEXAsyncInventory(metadata: List<RFIDReaderTagMetadata>? = null): ByteArray {
        var metadataXOR: Int = 0
        metadata?.forEach { metadataXOR = metadataXOR xor it.rawValue.toInt() }

        var dataLen: Int = 0x0A
        var body = byteArrayOf(0xFF.toByte(), dataLen.toByte()) + moduletechHeader()
        val exConfigData = ByteArray(20) // 20 zero bytes
        var subCommand = byteArrayOf(0xAA.toByte(), 0x58)
        subCommand = subCommand + exConfigData
        subCommand = subCommand + int2Bytes(metadataXOR.toLong() and 0xFFFF, 2) + byteArrayOf(0x00, 0x80.toByte(), 0x03)

        dataLen += subCommand.size
        val subCrc = getSubCRC(subCommand).toByte()
        dataLen += 1
        body = body + subCommand
        body = body + byteArrayOf(subCrc, MODULETECH_TERMINATOR)
        dataLen += 1

        body[1] = dataLen.toByte()
        return body + int2Bytes(calcCRC(body), 2)
    }

    fun stopEXAsyncInventory(): ByteArray {
        val subCommand = byteArrayOf(0xAA.toByte(), 0x59)
        val subCrc = getSubCRC(subCommand).toByte()
        val dataLen: Byte = 0x0E
        val body =
            byteArrayOf(0xFF.toByte(), dataLen) +
                moduletechHeader() +
                subCommand +
                byteArrayOf(subCrc, MODULETECH_TERMINATOR)
        return body + int2Bytes(calcCRC(body), 2)
    }

    fun getReaderConfiguration(readerConfiguration: RFIDReaderConfiguration): ByteArray {
        val data = byteArrayOf(0xFF.toByte(), 0x02, 0x9A.toByte(), 0x01, readerConfiguration.rawValue.toByte())
        return data + int2Bytes(calcCRC(data), 2)
    }

    fun setReaderConfiguration(
        readerConfiguration: RFIDReaderConfiguration,
        enable: Boolean,
    ): ByteArray {
        val data =
            byteArrayOf(
                0xFF.toByte(),
                0x03,
                0x9A.toByte(),
                0x01,
                readerConfiguration.rawValue.toByte(),
                if (enable) 0x01 else 0x00,
            )
        return data + int2Bytes(calcCRC(data), 2)
    }

    fun getSession(): ByteArray {
        val data = byteArrayOf(0xFF.toByte(), 0x02, 0x6B, 0x05, 0x00)
        return data + int2Bytes(calcCRC(data), 2)
    }

    fun setSession(session: RFIDReaderSession): ByteArray {
        val data = byteArrayOf(0xFF.toByte(), 0x03, 0x9B.toByte(), 0x05, 0x00, session.rawValue.toByte())
        return data + int2Bytes(calcCRC(data), 2)
    }

    fun getTarget(): ByteArray {
        val data = byteArrayOf(0xFF.toByte(), 0x02, 0x6B, 0x05, 0x01)
        return data + int2Bytes(calcCRC(data), 2)
    }

    fun setTarget(target: RFIDReaderTarget): ByteArray {
        var data = byteArrayOf(0xFF.toByte(), 0x04, 0x9B.toByte(), 0x05, 0x01)
        data =
            when (target) {
                RFIDReaderTarget.A -> data + byteArrayOf(0x01, 0x00)
                RFIDReaderTarget.B -> data + byteArrayOf(0x01, 0x01)
                RFIDReaderTarget.AB -> data + byteArrayOf(0x00, 0x00)
                RFIDReaderTarget.BA -> data + byteArrayOf(0x00, 0x01)
            }
        return data + int2Bytes(calcCRC(data), 2)
    }

    fun getRFMode(): ByteArray {
        val data = byteArrayOf(0xFF.toByte(), 0x02, 0x6B, 0x05, 0x02)
        return data + int2Bytes(calcCRC(data), 2)
    }

    fun setRFMode(rfMode: RFIDReaderRFMode): ByteArray {
        val data = byteArrayOf(0xFF.toByte(), 0x03, 0x9B.toByte(), 0x05, 0x02, rfMode.rawValue.toByte())
        return data + int2Bytes(calcCRC(data), 2)
    }

    fun getQ(): ByteArray {
        val data = byteArrayOf(0xFF.toByte(), 0x02, 0x6B, 0x05, 0x12)
        return data + int2Bytes(calcCRC(data), 2)
    }

    fun setQ(q: RFIDReaderQ?): ByteArray {
        val data =
            when (q) {
                RFIDReaderQ.DynamicQ ->
                    byteArrayOf(0xFF.toByte(), 0x03, 0x9B.toByte(), 0x05, 0x12, 0x00)
                is RFIDReaderQ.StaticQ ->
                    byteArrayOf(0xFF.toByte(), 0x04, 0x9B.toByte(), 0x05, 0x12, 0x01, q.value.toByte())
                null -> return ByteArray(0)
            }
        return data + int2Bytes(calcCRC(data), 2)
    }

    fun getTemperature(): ByteArray {
        val data = byteArrayOf(0xFF.toByte(), 0x00, 0x72)
        return data + int2Bytes(calcCRC(data), 2)
    }

    /** Shared header for every Moduletech sub-command payload. */
    private fun moduletechHeader(): ByteArray = byteArrayOf(0xAA.toByte()) + MODULETECH_PREAMBLE

    /** Exposed for tests / diagnostics — matches iOS `Messenger.activate`. */
    @Suppress("UNUSED_PARAMETER")
    fun activate(serialNumber: String): ByteArray = ByteArray(0)

    // Signature preserved to allow linkage of "unused" HEARTBEAT_PREFIX constant.
    @Suppress("unused")
    internal fun heartbeatPrefix(): ByteArray = HEARTBEAT_PREFIX
}
