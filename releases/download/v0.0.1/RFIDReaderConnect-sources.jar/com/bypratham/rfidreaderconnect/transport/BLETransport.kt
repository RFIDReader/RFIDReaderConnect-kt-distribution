package com.bypratham.rfidreaderconnect.transport

import android.annotation.SuppressLint
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothGatt
import android.bluetooth.BluetoothGattCallback
import android.bluetooth.BluetoothGattCharacteristic
import android.bluetooth.BluetoothGattDescriptor
import android.bluetooth.BluetoothGattService
import android.bluetooth.BluetoothManager
import android.bluetooth.BluetoothProfile
import android.bluetooth.BluetoothStatusCodes
import android.content.Context
import android.os.Build
import android.util.Log
import androidx.annotation.RequiresPermission
import com.bypratham.rfidreaderconnect.RFIDReaderError
import java.util.UUID

/**
 * Android BLE transport built on top of [BluetoothGatt].
 *
 * The reader is identified by its Bluetooth MAC address on Android — unlike
 * iOS, which uses a per-app peripheral UUID. The host application is
 * responsible for requesting `BLUETOOTH_SCAN` / `BLUETOOTH_CONNECT` runtime
 * permissions before calling [connect]; if the required permission is missing
 * a [SecurityException] is thrown at connect time.
 */
class BLETransport
    @JvmOverloads
    constructor(
        private val context: Context,
        /** BLE MAC address of the reader (e.g. `AA:BB:CC:DD:EE:FF`). */
        private val identifier: String,
        private val timeoutMs: Long = 30_000L,
        @Suppress("UNUSED_PARAMETER") maxRetries: Int? = null,
        @Suppress("UNUSED_PARAMETER") retryInterval: Int? = null,
        private val delegate: TransportDelegate,
        debug: Boolean = false,
    ) : TransportProtocol {
        private val tag = "[BLETransport]"
        private val logger: TransportLogger? = if (debug) TransportLogger(context, "BLE_$identifier") else null

        private val bluetoothManager: BluetoothManager? =
            context.getSystemService(Context.BLUETOOTH_SERVICE) as? BluetoothManager
        private val bluetoothAdapter: BluetoothAdapter? = bluetoothManager?.adapter

        private var gatt: BluetoothGatt? = null
        private var writeCharacteristic: BluetoothGattCharacteristic? = null
        private var readCharacteristic: BluetoothGattCharacteristic? = null
        private val writeLock = Any()
        private val pendingWrites = ArrayDeque<ByteArray>()
        private var writeInProgress: Boolean = false

        @Volatile
        private var ready: Boolean = false

        private val gattCallback =
            object : BluetoothGattCallback() {
                @SuppressLint("MissingPermission")
                override fun onConnectionStateChange(
                    gatt: BluetoothGatt,
                    status: Int,
                    newState: Int,
                ) {
                    when (newState) {
                        BluetoothProfile.STATE_CONNECTED -> {
                            delegate.transportDidConnect()
                            if (!gatt.requestMtu(MAX_MTU)) {
                                gatt.discoverServices()
                            }
                        }
                        BluetoothProfile.STATE_DISCONNECTED -> {
                            ready = false
                            synchronized(writeLock) {
                                pendingWrites.clear()
                                writeInProgress = false
                            }
                            this@BLETransport.gatt?.close()
                            this@BLETransport.gatt = null
                            delegate.transportDidDisconnect()
                        }
                    }
                }

                @SuppressLint("MissingPermission")
                override fun onMtuChanged(
                    gatt: BluetoothGatt,
                    mtu: Int,
                    status: Int,
                ) {
                    if (status != BluetoothGatt.GATT_SUCCESS) {
                        Log.w(tag, "MTU negotiation failed with status=$status; negotiated mtu=$mtu")
                    }
                    gatt.discoverServices()
                }

                @SuppressLint("MissingPermission")
                override fun onServicesDiscovered(
                    gatt: BluetoothGatt,
                    status: Int,
                ) {
                    if (status != BluetoothGatt.GATT_SUCCESS) {
                        Log.w(tag, "onServicesDiscovered: status=$status")
                        return
                    }
                    val service: BluetoothGattService? = gatt.getService(SERVICE_UUID)
                    if (service == null) {
                        Log.w(tag, "Service $SERVICE_UUID not present on device")
                        delegate.transportDidEncounteredError(
                            RFIDReaderError.TransportNotReady("BLE service $SERVICE_UUID not found."),
                        )
                        return
                    }
                    readCharacteristic = service.getCharacteristic(READ_UUID)
                    writeCharacteristic = service.getCharacteristic(WRITE_UUID)
                    val readChr = readCharacteristic
                    if (readChr == null || writeCharacteristic == null) {
                        Log.w(tag, "Read / write characteristics missing")
                        delegate.transportDidEncounteredError(
                            RFIDReaderError.TransportNotReady("BLE characteristics not discovered."),
                        )
                        return
                    }
                    gatt.setCharacteristicNotification(readChr, true)
                    val descriptor: BluetoothGattDescriptor? = readChr.getDescriptor(CCC_DESCRIPTOR_UUID)
                    if (descriptor != null) {
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                            gatt.writeDescriptor(descriptor, BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE)
                        } else {
                            @Suppress("DEPRECATION")
                            descriptor.value = BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE
                            @Suppress("DEPRECATION")
                            gatt.writeDescriptor(descriptor)
                        }
                    }
                    ready = true
                    delegate.transportDidBecomeReady()
                }

                @Suppress("DEPRECATION")
                override fun onCharacteristicChanged(
                    gatt: BluetoothGatt,
                    characteristic: BluetoothGattCharacteristic,
                ) {
                    if (Build.VERSION.SDK_INT < Build.VERSION_CODES.TIRAMISU) {
                        val value = characteristic.value ?: return
                        logger?.log(value, TransportLogger.Action.RECEIVE)
                        delegate.transportDidReceiveMessage(value.copyOf())
                    }
                }

                override fun onCharacteristicChanged(
                    gatt: BluetoothGatt,
                    characteristic: BluetoothGattCharacteristic,
                    value: ByteArray,
                ) {
                    logger?.log(value, TransportLogger.Action.RECEIVE)
                    delegate.transportDidReceiveMessage(value.copyOf())
                }

                override fun onCharacteristicWrite(
                    gatt: BluetoothGatt,
                    characteristic: BluetoothGattCharacteristic,
                    status: Int,
                ) {
                    if (status == BluetoothGatt.GATT_SUCCESS) {
                        synchronized(writeLock) { writeInProgress = false }
                        delegate.transportDidWriteMessage()
                        drainNextWrite()
                    } else {
                        failQueuedWrite("BLE characteristic write failed with status=$status.")
                    }
                }
            }

        @RequiresPermission("android.permission.BLUETOOTH_CONNECT")
        override fun connect() {
            val adapter =
                bluetoothAdapter
                    ?: throw RFIDReaderError.TransportNotReady("BluetoothAdapter unavailable.")
            if (!adapter.isEnabled) {
                Log.w(tag, "Bluetooth adapter is disabled. Cannot connect.")
            }
            val device: BluetoothDevice =
                try {
                    adapter.getRemoteDevice(identifier)
                } catch (iae: IllegalArgumentException) {
                    delegate.transportDidEncounteredError(iae)
                    return
                }
            gatt = device.connectGatt(context, false, gattCallback, BluetoothDevice.TRANSPORT_LE)
        }

        @RequiresPermission("android.permission.BLUETOOTH_CONNECT")
        override fun disconnect() {
            gatt?.disconnect()
        }

        @RequiresPermission("android.permission.BLUETOOTH_CONNECT")
        override fun sendData(data: ByteArray): ByteArray? {
            if (!ready) {
                throw RFIDReaderError.TransportNotReady("Transport is not ready to send data.")
            }
            synchronized(writeLock) {
                pendingWrites.addLast(data.copyOf())
            }
            drainNextWrite()
            return null
        }

        @SuppressLint("MissingPermission")
        private fun drainNextWrite() {
            val data =
                synchronized(writeLock) {
                    if (writeInProgress || pendingWrites.isEmpty()) return
                    writeInProgress = true
                    pendingWrites.removeFirst()
                }
            val characteristic = writeCharacteristic
            val currentGatt = gatt
            if (characteristic == null || currentGatt == null || !ready) {
                failQueuedWrite("BLE transport became unavailable while writing.")
                return
            }
            logger?.log(data, TransportLogger.Action.SEND)
            val accepted =
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                    currentGatt.writeCharacteristic(
                        characteristic,
                        data,
                        BluetoothGattCharacteristic.WRITE_TYPE_DEFAULT,
                    ) == BluetoothStatusCodes.SUCCESS
                } else {
                    @Suppress("DEPRECATION")
                    characteristic.value = data
                    @Suppress("DEPRECATION")
                    characteristic.writeType = BluetoothGattCharacteristic.WRITE_TYPE_DEFAULT
                    @Suppress("DEPRECATION")
                    currentGatt.writeCharacteristic(characteristic)
                }
            if (!accepted) failQueuedWrite("Android rejected the BLE characteristic write.")
        }

        private fun failQueuedWrite(message: String) {
            synchronized(writeLock) {
                writeInProgress = false
                pendingWrites.clear()
            }
            delegate.transportDidEncounteredError(RFIDReaderError.TransportNotReady(message))
        }

        companion object {
            val SERVICE_UUID: UUID = UUID.fromString("31306C34-7735-3134-6A6D-346837347270")
            val READ_UUID: UUID = UUID.fromString("32306C34-7735-3134-6A6D-346837347270")
            val WRITE_UUID: UUID = UUID.fromString("33306C34-7735-3134-6A6D-346837347270")
            private const val MAX_MTU = 517
            private val CCC_DESCRIPTOR_UUID: UUID = UUID.fromString("00002902-0000-1000-8000-00805f9b34fb")
        }
    }
