package com.bypratham.rfidreaderconnect.transport

/** Contract every concrete transport implementation must satisfy. */
interface TransportProtocol {
    fun connect()

    fun disconnect()

    /**
     * Sends a fully-formed frame to the reader. Returns any synchronously
     * available response (unused today; TCP/BLE / USB return null).
     */
    @Throws(Exception::class)
    fun sendData(data: ByteArray): ByteArray?
}
