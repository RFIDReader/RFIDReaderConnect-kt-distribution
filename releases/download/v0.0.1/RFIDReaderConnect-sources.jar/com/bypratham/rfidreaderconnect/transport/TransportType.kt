package com.bypratham.rfidreaderconnect.transport

import android.content.Context
import android.hardware.usb.UsbDevice

/** WiFi transport sub-mode. */
enum class WiFiTransportMode {
    /** Raw TCP socket over the reader's `tcpPort` (default 81). */
    TCP,

    /** UDP datagrams over the reader's `udpPort` (default 82). */
    UDP,
}

/**
 * Discriminated union that selects the concrete transport at reader-construction time.
 *
 * Android note: [Ble] and [Usb] carry a `Context` because Android's Bluetooth /
 * USB stacks are Context-scoped. iOS does not need this.
 */
sealed class TransportType {
    data class Ble(
        val context: Context,
        /** BLE MAC address (Android identifies remote devices by MAC, not a service UUID). */
        val identifier: String,
        val connectionTimeout: Long = 30_000L,
        val maxRetries: Int? = null,
        val retryInterval: Int? = null,
        val debug: Boolean = false,
    ) : TransportType()

    data class WiFi(
        val host: String,
        val httpPort: String = "80",
        val tcpPort: String = "81",
        val udpPort: String = "82",
        val mode: WiFiTransportMode,
        val maxRetries: Int? = null,
        val retryInterval: Int? = null,
        val debug: Boolean = false,
    ) : TransportType()

    data class Usb(
        val context: Context,
        val device: UsbDevice? = null,
        val portName: String? = null,
        val debug: Boolean = false,
    ) : TransportType()
}
