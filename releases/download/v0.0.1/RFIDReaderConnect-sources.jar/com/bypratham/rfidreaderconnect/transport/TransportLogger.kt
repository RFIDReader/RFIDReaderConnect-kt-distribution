package com.bypratham.rfidreaderconnect.transport

import android.content.Context
import android.util.Log
import com.bypratham.rfidreaderconnect.toHex
import java.io.File
import java.io.FileOutputStream
import java.util.concurrent.Executors
import java.util.concurrent.ScheduledExecutorService
import java.util.concurrent.TimeUnit

/**
 * Debug logger that writes hex traces for every transport frame to logcat and
 * (optionally) to files under the app's `filesDir`. Mirrors iOS `TransportLogger`.
 */
internal class TransportLogger(
    private val context: Context?,
    deviceName: String,
    private val enableFileLogging: Boolean = true,
) {
    enum class Action(val symbol: String) {
        SEND("^"),
        RECEIVE("v"),
    }

    private val tag = "[TransportLogger:$deviceName]"
    private val safeName = deviceName.replace("/", "_")

    private val txFile: File?
    private val rxFile: File?
    private val csvFile: File?

    private val executor: ScheduledExecutorService =
        Executors.newSingleThreadScheduledExecutor { r ->
            Thread(r, "rfid-transport-logger").apply { isDaemon = true }
        }

    private val txBuffer = ArrayDeque<String>()
    private val rxBuffer = ArrayDeque<String>()
    private val csvBuffer = ArrayDeque<String>()

    private val flushThreshold = 20
    private val flushIntervalMs = 1_000L

    init {
        if (enableFileLogging && context != null) {
            val baseDir = context.filesDir
            txFile = File(baseDir, "$safeName.tx.log").also { it.delete() }
            rxFile = File(baseDir, "$safeName.rx.log").also { it.delete() }
            csvFile = File(baseDir, "$safeName.csv").also { it.delete() }
            executor.execute { csvBuffer.addLast("\"ACTION\",\"DATA\"") }
        } else {
            txFile = null
            rxFile = null
            csvFile = null
        }
        executor.scheduleAtFixedRate(::flush, flushIntervalMs, flushIntervalMs, TimeUnit.MILLISECONDS)
    }

    fun log(
        data: ByteArray,
        action: Action,
    ) {
        val hex = data.toHex()
        Log.d(tag, "${action.symbol} $hex")
        if (!enableFileLogging || context == null) return
        executor.execute {
            when (action) {
                Action.SEND -> txBuffer.addLast(hex)
                Action.RECEIVE -> rxBuffer.addLast(hex)
            }
            csvBuffer.addLast("${action.symbol},$hex")
            if (txBuffer.size >= flushThreshold ||
                rxBuffer.size >= flushThreshold ||
                csvBuffer.size >= flushThreshold
            ) {
                flush()
            }
        }
    }

    private fun flush() {
        writeBuffer(txBuffer, txFile)
        writeBuffer(rxBuffer, rxFile)
        writeBuffer(csvBuffer, csvFile)
    }

    private fun writeBuffer(
        buffer: ArrayDeque<String>,
        file: File?,
    ) {
        if (file == null || buffer.isEmpty()) return
        val payload = buildString {
            while (buffer.isNotEmpty()) {
                append(buffer.removeFirst())
                append('\n')
            }
        }
        runCatching {
            FileOutputStream(file, /* append = */ true).use { it.write(payload.toByteArray()) }
        }
    }

    fun stop() {
        executor.execute(::flush)
        executor.shutdown()
    }
}
