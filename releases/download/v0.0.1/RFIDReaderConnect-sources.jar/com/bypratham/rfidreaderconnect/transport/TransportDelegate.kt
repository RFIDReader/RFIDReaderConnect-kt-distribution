package com.bypratham.rfidreaderconnect.transport

/** Callback surface a transport uses to notify `RFIDReader` of connection lifecycle + received bytes. */
interface TransportDelegate {
    fun transportDidConnect()

    fun transportDidBecomeReady()

    fun transportDidDisconnect()

    fun transportDidWriteMessage()

    fun transportDidReceiveMessage(data: ByteArray?)

    fun transportDidEncounteredError(error: Throwable)
}
