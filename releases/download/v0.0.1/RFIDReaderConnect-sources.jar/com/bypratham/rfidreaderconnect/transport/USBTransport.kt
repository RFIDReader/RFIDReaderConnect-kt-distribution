package com.bypratham.rfidreaderconnect.transport

import android.content.Context
import android.hardware.usb.UsbConstants
import android.hardware.usb.UsbDevice
import android.hardware.usb.UsbDeviceConnection
import android.hardware.usb.UsbEndpoint
import android.hardware.usb.UsbInterface
import android.hardware.usb.UsbManager
import android.util.Log
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

/**
 * USB Host transport for readers exposed as CDC-ACM devices (VID `0x303A`).
 *
 * Permission handling: this SDK assumes the host application has already been
 * granted `usbManager.hasPermission(device)`. Callers should request USB
 * permission via a `PendingIntent`-based `requestPermission` before calling
 * [connect]; otherwise `connect()` reports an error to the delegate.
 */
class USBTransport
    @JvmOverloads
    constructor(
        private val context: Context,
        private var device: UsbDevice? = null,
        @Suppress("UNUSED_PARAMETER") portName: String? = null,
        private val delegate: TransportDelegate,
        debug: Boolean = false,
    ) : TransportProtocol {
        private val tag = "[USBTransport]"
        private val logger: TransportLogger? = if (debug) TransportLogger(context, "USB", enableFileLogging = false) else null

        private val usbManager: UsbManager? = context.getSystemService(Context.USB_SERVICE) as? UsbManager

        private var connection: UsbDeviceConnection? = null
        private var iface: UsbInterface? = null
        private var bulkIn: UsbEndpoint? = null
        private var bulkOut: UsbEndpoint? = null

        private var job: Job = SupervisorJob()
        private var scope = CoroutineScope(Dispatchers.IO + job)

        @Volatile
        private var ready: Boolean = false

        override fun connect() {
            if (!job.isActive) {
                job = SupervisorJob()
                scope = CoroutineScope(Dispatchers.IO + job)
            }
            val manager = usbManager
            if (manager == null) {
                delegate.transportDidEncounteredError(IllegalStateException("USB service unavailable."))
                return
            }
            val target =
                device
                    ?: manager.deviceList.values.firstOrNull { it.vendorId == USB_VENDOR_ID }
                    ?: run {
                        delegate.transportDidEncounteredError(
                            IllegalStateException("No USB device with VID=0x303A attached."),
                        )
                        return
                    }
            if (!manager.hasPermission(target)) {
                delegate.transportDidEncounteredError(
                    SecurityException("USB permission not granted for ${target.deviceName}. Request it from the host app first."),
                )
                return
            }
            device = target
            val cdcInterface = findCdcDataInterface(target)
            if (cdcInterface == null) {
                delegate.transportDidEncounteredError(
                    IllegalStateException("No CDC-DATA interface (class 0x0A) on ${target.deviceName}."),
                )
                return
            }
            val (inEp, outEp) = findBulkEndpoints(cdcInterface)
            if (inEp == null || outEp == null) {
                delegate.transportDidEncounteredError(
                    IllegalStateException("Bulk IN / OUT endpoints missing on CDC interface."),
                )
                return
            }
            val conn = manager.openDevice(target)
            if (conn == null) {
                delegate.transportDidEncounteredError(IllegalStateException("openDevice returned null."))
                return
            }
            if (!conn.claimInterface(cdcInterface, true)) {
                conn.close()
                delegate.transportDidEncounteredError(IllegalStateException("claimInterface failed."))
                return
            }
            connection = conn
            iface = cdcInterface
            bulkIn = inEp
            bulkOut = outEp
            ready = true
            delegate.transportDidConnect()
            delegate.transportDidBecomeReady()
            scope.launch { readLoop() }
        }

        private fun readLoop() {
            val conn = connection ?: return
            val endpoint = bulkIn ?: return
            val buffer = ByteArray(endpoint.maxPacketSize.coerceAtLeast(64))
            while (scope.isActive && ready) {
                val read =
                    try {
                        conn.bulkTransfer(endpoint, buffer, buffer.size, 100)
                    } catch (t: Throwable) {
                        Log.w(tag, "bulkTransfer(IN) failed: ${t.message}")
                        -1
                    }
                if (read > 0) {
                    val chunk = buffer.copyOfRange(0, read)
                    logger?.log(chunk, TransportLogger.Action.RECEIVE)
                    delegate.transportDidReceiveMessage(chunk)
                }
            }
        }

        override fun disconnect() {
            ready = false
            val conn = connection
            val i = iface
            if (conn != null && i != null) {
                conn.releaseInterface(i)
                conn.close()
            }
            connection = null
            iface = null
            bulkIn = null
            bulkOut = null
            delegate.transportDidDisconnect()
            scope.cancel()
        }

        override fun sendData(data: ByteArray): ByteArray? {
            if (!ready) return null
            val conn = connection ?: return null
            val endpoint = bulkOut ?: return null
            logger?.log(data, TransportLogger.Action.SEND)
            val written = conn.bulkTransfer(endpoint, data, data.size, 500)
            if (written >= 0) {
                delegate.transportDidWriteMessage()
            }
            return null
        }

        private fun findCdcDataInterface(device: UsbDevice): UsbInterface? {
            for (i in 0 until device.interfaceCount) {
                val ui = device.getInterface(i)
                if (ui.interfaceClass == UsbConstants.USB_CLASS_CDC_DATA) return ui
            }
            return null
        }

        private fun findBulkEndpoints(ui: UsbInterface): Pair<UsbEndpoint?, UsbEndpoint?> {
            var inEp: UsbEndpoint? = null
            var outEp: UsbEndpoint? = null
            for (i in 0 until ui.endpointCount) {
                val ep = ui.getEndpoint(i)
                if (ep.type != UsbConstants.USB_ENDPOINT_XFER_BULK) continue
                if (ep.direction == UsbConstants.USB_DIR_IN) inEp = ep else outEp = ep
            }
            return inEp to outEp
        }

        companion object {
            /** ESP32-S3 USB VID used by Mark3 firmware. */
            const val USB_VENDOR_ID: Int = 0x303A
        }
    }
