package com.bypratham.rfidreaderconnect.transport

import android.util.Log
import com.bypratham.rfidreaderconnect.RFIDReaderError
import com.bypratham.rfidreaderconnect.performHttpRequest
import com.bypratham.rfidreaderconnect.sanitizeHost
import com.bypratham.rfidreaderconnect.sanitizePort
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetSocketAddress
import java.net.Socket
import java.util.concurrent.atomic.AtomicBoolean

/**
 * WiFi transport that speaks either raw TCP or UDP to the reader.
 *
 * Before opening the socket, the transport asks the reader's HTTP service to
 * resolve its socket host. This mirrors the Apple SDK and supports readers
 * that advertise a different reachable address from the one initially used.
 */
class WiFiTransport
    @JvmOverloads
    constructor(
        host: String,
        httpPort: String = "80",
        tcpPort: String = "81",
        udpPort: String = "82",
        private val transportMode: WiFiTransportMode,
        @Suppress("UNUSED_PARAMETER") maxRetries: Int? = null,
        @Suppress("UNUSED_PARAMETER") retryInterval: Int? = null,
        private val delegate: TransportDelegate,
        debug: Boolean = false,
    ) : TransportProtocol {
        private val tag = "[WiFiTransport]"
        val host: String = sanitizeHost(host)
        val httpPort: String = sanitizePort(httpPort)
        val tcpPort: String = sanitizePort(tcpPort)
        val udpPort: String = sanitizePort(udpPort)
        private val logger: TransportLogger? =
            if (debug) TransportLogger(null, "WiFi_$host", enableFileLogging = false) else null

        @Volatile
        private var resolvedHost: String? = null

        private var tcpSocket: Socket? = null
        private var udpSocket: DatagramSocket? = null
        private var udpTargetAddress: InetSocketAddress? = null

        private var job: Job = SupervisorJob()
        private var scope = CoroutineScope(Dispatchers.IO + job)
        private val ready = AtomicBoolean(false)

        override fun connect() {
            if (!job.isActive) {
                job = SupervisorJob()
                scope = CoroutineScope(Dispatchers.IO + job)
            }
            scope.launch {
                try {
                    val (data, response) =
                        performHttpRequest(
                            urlStr = "http://$host:$httpPort/resolve",
                            method = "GET",
                            timeoutMillis = 5_000,
                        )
                    delegate.transportDidConnect()
                    resolvedHost =
                        if (response.statusCode == 200) {
                            data.toString(Charsets.UTF_8).trim().ifEmpty { host }
                        } else {
                            Log.w(tag, "Host resolution returned HTTP ${response.statusCode}; using $host")
                            host
                        }
                    when (transportMode) {
                        WiFiTransportMode.TCP -> connectTcp()
                        WiFiTransportMode.UDP -> connectUdp()
                    }
                } catch (t: Throwable) {
                    Log.e(tag, "connect failed", t)
                    delegate.transportDidDisconnect()
                }
            }
        }

        private fun connectTcp() {
            val port = tcpPort.toIntOrNull() ?: throw RFIDReaderError.TransportNotReady("Invalid tcpPort $tcpPort")
            val socket = Socket()
            socket.connect(InetSocketAddress(resolvedHost ?: host, port), 10_000)
            tcpSocket = socket
            ready.set(true)
            delegate.transportDidBecomeReady()
            scope.launch { readTcpLoop(socket) }
        }

        private suspend fun readTcpLoop(socket: Socket) {
            val stream = socket.getInputStream()
            val buffer = ByteArray(65_536)
            while (scope.isActive && !socket.isClosed) {
                val read =
                    try {
                        stream.read(buffer)
                    } catch (t: Throwable) {
                        Log.w(tag, "TCP read failed: ${t.message}")
                        -1
                    }
                if (read <= 0) {
                    ready.set(false)
                    delegate.transportDidDisconnect()
                    return
                }
                val chunk = buffer.copyOfRange(0, read)
                logger?.log(chunk, TransportLogger.Action.RECEIVE)
                delegate.transportDidReceiveMessage(chunk)
            }
        }

        private fun connectUdp() {
            val port = udpPort.toIntOrNull() ?: throw RFIDReaderError.TransportNotReady("Invalid udpPort $udpPort")
            val socket = DatagramSocket()
            udpSocket = socket
            udpTargetAddress = InetSocketAddress(resolvedHost ?: host, port)
            ready.set(true)
            delegate.transportDidBecomeReady()
            scope.launch { readUdpLoop(socket) }
        }

        private fun readUdpLoop(socket: DatagramSocket) {
            val buffer = ByteArray(65_536)
            while (scope.isActive && !socket.isClosed) {
                val packet = DatagramPacket(buffer, buffer.size)
                try {
                    socket.receive(packet)
                } catch (t: Throwable) {
                    Log.w(tag, "UDP receive failed: ${t.message}")
                    ready.set(false)
                    delegate.transportDidDisconnect()
                    return
                }
                val chunk = packet.data.copyOfRange(packet.offset, packet.offset + packet.length)
                logger?.log(chunk, TransportLogger.Action.RECEIVE)
                delegate.transportDidReceiveMessage(chunk)
            }
        }

        override fun disconnect() {
            ready.set(false)
            runCatching { tcpSocket?.close() }
            runCatching { udpSocket?.close() }
            tcpSocket = null
            udpSocket = null
            resolvedHost = null
            delegate.transportDidDisconnect()
            scope.cancel()
        }

        override fun sendData(data: ByteArray): ByteArray? {
            if (!ready.get()) throw RFIDReaderError.TransportNotReady("Transport is not ready to send data.")
            logger?.log(data, TransportLogger.Action.SEND)
            when (transportMode) {
                WiFiTransportMode.TCP -> {
                    val socket = tcpSocket ?: throw RFIDReaderError.TransportNotReady("TCP socket unavailable.")
                    scope.launch {
                        try {
                            socket.getOutputStream().apply {
                                write(data)
                                flush()
                            }
                            delegate.transportDidWriteMessage()
                        } catch (t: Throwable) {
                            Log.e(tag, "TCP send failed", t)
                            delegate.transportDidEncounteredError(t)
                        }
                    }
                }
                WiFiTransportMode.UDP -> {
                    val socket = udpSocket ?: throw RFIDReaderError.TransportNotReady("UDP socket unavailable.")
                    val target = udpTargetAddress ?: throw RFIDReaderError.TransportNotReady("UDP target unavailable.")
                    scope.launch {
                        try {
                            socket.send(DatagramPacket(data, data.size, target))
                            delegate.transportDidWriteMessage()
                        } catch (t: Throwable) {
                            Log.e(tag, "UDP send failed", t)
                            delegate.transportDidEncounteredError(t)
                        }
                    }
                }
            }
            return null
        }
    }
