package com.bypratham.rfidreaderconnect

/**
 * Callback surface the SDK uses to deliver reader lifecycle + parsed messages.
 *
 * Every method has a default empty implementation, so callers only need to
 * override what they care about. Callbacks are dispatched on the Android main
 * thread (parity with iOS which dispatches on `DispatchQueue.main`).
 */
interface RFIDReaderDelegate {
    /** Reader connection has been established at the transport layer. */
    fun rfidReaderDidConnect() {}

    /** Reader has finished bootstrapping and is ready to accept commands. */
    fun rfidReaderDidBecomeReady() {}

    /** Reader (or transport) has been disconnected. */
    fun rfidReaderDidDisconnect() {}

    /** A parsed message from the reader (type depends on the command). */
    fun rfidReaderDidReceiveMessage(message: Any) {}

    /** An asynchronous inventory has just started. */
    fun rfidReaderDidStartScanning() {}

    /** An asynchronous inventory has stopped. */
    fun rfidReaderDidStopScanning() {}

    /** A tag has been read (from either single or asynchronous inventory). */
    fun rfidReaderDidReadTag(tag: RFIDTag) {}

    /** SDK / reader encountered an error. */
    fun rfidReaderDidEncounteredError(error: Throwable) {}

    /**
     * Fires for every raw response frame BEFORE parsing. Useful for bridged
     * clients (e.g. a web app) that maintain their own wire-protocol parser.
     */
    fun rfidReaderDidReceiveRawData(data: ByteArray) {}
}
