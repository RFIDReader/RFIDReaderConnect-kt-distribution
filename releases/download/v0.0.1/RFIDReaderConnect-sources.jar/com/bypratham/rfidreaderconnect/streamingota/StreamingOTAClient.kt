package com.bypratham.rfidreaderconnect.streamingota

import android.os.Handler
import android.os.Looper
import com.bypratham.rfidreaderconnect.RFIDReader
import com.bypratham.rfidreaderconnect.messages.Messenger
import java.security.MessageDigest
import java.util.concurrent.Executors
import java.util.concurrent.ScheduledFuture
import java.util.concurrent.TimeUnit

/** Progress and terminal events reported by a [StreamingOTAClient] session. */
interface StreamingOTAClientDelegate {
    /** The reader accepted BEGIN and reserved a flash slot. */
    fun streamingOTADidBegin(
        maxChunk: UShort,
        partitionSize: UInt,
    )

    /** Device-confirmed flash-write progress (normally reported every ~16 KiB). */
    fun streamingOTADidProgress(
        bytesWritten: UInt,
        totalBytes: UInt,
        seqAck: UShort,
    )

    /** The image was verified, selected as boot partition, and the reader will reboot. */
    fun streamingOTADidComplete()

    /** The session ended with an error. */
    fun streamingOTADidFail(error: StreamingOTAError)

    /** Host-side, per-chunk queue progress suitable for a smooth progress bar and ETA. */
    fun streamingOTADidQueueBytes(
        queued: UInt,
        totalBytes: UInt,
    ) {}
}

/** Streaming OTA failure taxonomy, equivalent to the Apple SDK. */
sealed class StreamingOTAError(
    message: String,
    cause: Throwable? = null,
) : Exception(message, cause) {
    data object NotConnected : StreamingOTAError("reader not connected")

    data class InvalidImage(val reason: String) : StreamingOTAError("invalid image: $reason")

    data object BeginTimeout : StreamingOTAError("device did not respond to BEGIN in time")

    data object EndTimeout : StreamingOTAError("device did not respond to END in time")

    data class DeviceRejected(
        val cmd: UByte,
        val status: UByte,
        val deviceMessage: String,
    ) : StreamingOTAError(
            "device rejected 0x%02X with status 0x%02X (%s)".format(
                cmd.toInt(),
                status.toInt(),
                deviceMessage,
            ),
        )

    data class TransportError(val underlying: Throwable) :
        StreamingOTAError("transport error: ${underlying.message}", underlying)
}

/**
 * Host-side driver for the Mark 3 transport-agnostic streaming OTA protocol.
 *
 * It works over the reader's active transport (normally BLE or USB). Wi-Fi can
 * continue to use [RFIDReader.performOTA] for the faster HTTPS-pull path.
 */
class StreamingOTAClient(
    private val reader: RFIDReader,
) {
    private val mainHandler = Handler(Looper.getMainLooper())
    private val executor =
        Executors.newSingleThreadScheduledExecutor { runnable ->
            Thread(runnable, "rfid-streaming-ota").apply { isDaemon = true }
        }

    private var delegate: StreamingOTAClientDelegate? = null
    private var imageData: ByteArray = ByteArray(0)
    private var expectedSha: ByteArray = ByteArray(0)
    private var version: String = ""
    private var maxChunk: Int = 0
    private var seq: UShort = 0u
    private var offset: Int = 0
    private var beginTimer: ScheduledFuture<*>? = null
    private var endTimer: ScheduledFuture<*>? = null
    private var sendTimer: ScheduledFuture<*>? = null
    private var frameObserver: ((cmd: Int, status: UShort, data: ByteArray) -> Unit)? = null
    private var errorObserver: ((error: Throwable) -> Unit)? = null

    /**
     * Streams [imageData] after the reader validates the BEGIN request.
     * [sha256] must contain the 32-byte SHA-256 digest of [imageData].
     */
    fun start(
        imageData: ByteArray,
        sha256: ByteArray,
        version: String,
        delegate: StreamingOTAClientDelegate,
    ) {
        executor.execute {
            if (!reader.isConnected) {
                report(StreamingOTAError.NotConnected, delegate)
                return@execute
            }
            if (imageData.isEmpty()) {
                report(StreamingOTAError.InvalidImage("empty"), delegate)
                return@execute
            }
            if (sha256.size != SHA256_LENGTH) {
                report(StreamingOTAError.InvalidImage("sha256 must be 32 bytes"), delegate)
                return@execute
            }
            if (imageData.size.toLong() > UInt.MAX_VALUE.toLong()) {
                report(StreamingOTAError.InvalidImage("image exceeds 4 GiB protocol limit"), delegate)
                return@execute
            }

            cleanup()
            this.delegate = delegate
            this.imageData = imageData.copyOf()
            expectedSha = sha256.copyOf()
            this.version = version

            frameObserver = { cmd, status, data ->
                executor.execute { handleFrame(cmd, status, data) }
            }
            errorObserver = { error ->
                executor.execute { terminate(StreamingOTAError.TransportError(error)) }
            }
            reader.streamingOTAFrameObserver = frameObserver
            reader.streamingOTAErrorObserver = errorObserver
            try {
                reader.sendStreamingOTAFrame(
                    Messenger.streamingOTABegin(imageData.size.toUInt(), sha256, version),
                )
            } catch (error: Throwable) {
                terminate(StreamingOTAError.TransportError(error))
                return@execute
            }
            beginTimer =
                executor.schedule(
                    {
                        if (maxChunk == 0) terminate(StreamingOTAError.BeginTimeout)
                    },
                    BEGIN_TIMEOUT_SECONDS,
                    TimeUnit.SECONDS,
                )
        }
    }

    /** Best-effort user-initiated abort. */
    fun abort() {
        executor.execute {
            runCatching { reader.sendStreamingOTAFrame(Messenger.streamingOTAAbort) }
                .onFailure { terminate(StreamingOTAError.TransportError(it)) }
        }
    }

    private fun handleFrame(
        cmd: Int,
        status: UShort,
        data: ByteArray,
    ) {
        val statusCode = ((status.toInt() shr 8) and 0xFF).toUByte()
        when (cmd) {
            Messenger.STREAMING_OTA_CMD_BEGIN -> handleBegin(statusCode, data)
            Messenger.STREAMING_OTA_CMD_DATA -> handleData(statusCode, data)
            Messenger.STREAMING_OTA_CMD_END -> handleEnd(statusCode)
            Messenger.STREAMING_OTA_CMD_ABORT -> reject(Messenger.STREAMING_OTA_CMD_ABORT, statusCode)
        }
    }

    private fun handleBegin(
        statusCode: UByte,
        data: ByteArray,
    ) {
        beginTimer?.cancel(false)
        beginTimer = null
        if (statusCode != 0.toUByte()) {
            reject(Messenger.STREAMING_OTA_CMD_BEGIN, statusCode)
            return
        }
        if (data.size < BEGIN_RESPONSE_LENGTH) {
            terminate(
                StreamingOTAError.DeviceRejected(
                    Messenger.STREAMING_OTA_CMD_BEGIN.toUByte(),
                    0xFFu,
                    "BEGIN OK reply missing payload",
                ),
            )
            return
        }
        val negotiatedChunk = littleEndianUShort(data, 0)
        val partitionSize = littleEndianUInt(data, 2)
        if (negotiatedChunk == 0.toUShort()) {
            terminate(
                StreamingOTAError.DeviceRejected(
                    Messenger.STREAMING_OTA_CMD_BEGIN.toUByte(),
                    0xFFu,
                    "BEGIN OK reply returned a zero max chunk",
                ),
            )
            return
        }
        maxChunk = negotiatedChunk.toInt()
        val target = delegate
        dispatchMain { target?.streamingOTADidBegin(negotiatedChunk, partitionSize) }
        startSending()
    }

    private fun handleData(
        statusCode: UByte,
        data: ByteArray,
    ) {
        if (statusCode != 0.toUByte()) {
            reject(Messenger.STREAMING_OTA_CMD_DATA, statusCode)
            return
        }
        if (data.size < DATA_RESPONSE_LENGTH) return
        val bytesWritten = littleEndianUInt(data, 0)
        val seqAck = littleEndianUShort(data, 4)
        val totalBytes = imageData.size.toUInt()
        val target = delegate
        dispatchMain { target?.streamingOTADidProgress(bytesWritten, totalBytes, seqAck) }
    }

    private fun handleEnd(statusCode: UByte) {
        endTimer?.cancel(false)
        endTimer = null
        if (statusCode != 0.toUByte()) {
            reject(Messenger.STREAMING_OTA_CMD_END, statusCode)
            return
        }
        val target = delegate
        dispatchMain { target?.streamingOTADidComplete() }
        cleanup()
    }

    private fun reject(
        cmd: Int,
        statusCode: UByte,
    ) {
        terminate(
            StreamingOTAError.DeviceRejected(
                cmd.toUByte(),
                statusCode,
                STATUS_NAMES[statusCode] ?: "unknown",
            ),
        )
    }

    private fun startSending() {
        sendTimer?.cancel(false)
        sendTimer =
            executor.scheduleWithFixedDelay(
                ::sendOneChunkOrFinish,
                0,
                SEND_INTERVAL_NANOS,
                TimeUnit.NANOSECONDS,
            )
    }

    private fun sendOneChunkOrFinish() {
        try {
            if (offset >= imageData.size) {
                sendTimer?.cancel(false)
                sendTimer = null
                reader.sendStreamingOTAFrame(Messenger.streamingOTAEnd)
                endTimer =
                    executor.schedule(
                        { terminate(StreamingOTAError.EndTimeout) },
                        END_TIMEOUT_SECONDS,
                        TimeUnit.SECONDS,
                    )
                return
            }
            val end = (offset + maxChunk).coerceAtMost(imageData.size)
            reader.sendStreamingOTAFrame(Messenger.streamingOTAData(seq, imageData.copyOfRange(offset, end)))
            offset = end
            seq = (seq + 1u).toUShort()
            val queued = offset.toUInt()
            val total = imageData.size.toUInt()
            val target = delegate
            dispatchMain { target?.streamingOTADidQueueBytes(queued, total) }
        } catch (error: Throwable) {
            terminate(StreamingOTAError.TransportError(error))
        }
    }

    private fun terminate(error: StreamingOTAError) {
        report(error, delegate)
        cleanup()
    }

    private fun report(
        error: StreamingOTAError,
        target: StreamingOTAClientDelegate?,
    ) {
        dispatchMain { target?.streamingOTADidFail(error) }
    }

    private fun dispatchMain(block: () -> Unit) {
        mainHandler.post(block)
    }

    private fun cleanup() {
        beginTimer?.cancel(false)
        endTimer?.cancel(false)
        sendTimer?.cancel(false)
        beginTimer = null
        endTimer = null
        sendTimer = null
        if (reader.streamingOTAFrameObserver === frameObserver) reader.streamingOTAFrameObserver = null
        if (reader.streamingOTAErrorObserver === errorObserver) reader.streamingOTAErrorObserver = null
        frameObserver = null
        errorObserver = null
        imageData = ByteArray(0)
        expectedSha = ByteArray(0)
        version = ""
        maxChunk = 0
        seq = 0u
        offset = 0
        delegate = null
    }

    companion object {
        internal val STATUS_NAMES: Map<UByte, String> =
            mapOf(
                0x00u.toUByte() to "OK",
                0x01u.toUByte() to "BUSY",
                0x02u.toUByte() to "NO_PARTITION",
                0x03u.toUByte() to "IMAGE_TOO_LARGE",
                0x04u.toUByte() to "FLASH_WRITE",
                0x05u.toUByte() to "BAD_SEQUENCE",
                0x06u.toUByte() to "BAD_STATE",
                0x07u.toUByte() to "SHA_MISMATCH",
                0x08u.toUByte() to "VALIDATE_FAILED",
                0x09u.toUByte() to "SET_BOOT_FAILED",
                0x0Au.toUByte() to "ABORTED",
                0x0Bu.toUByte() to "TIMEOUT",
                0x0Cu.toUByte() to "OOM",
            )

        private const val SHA256_LENGTH = 32
        private const val BEGIN_RESPONSE_LENGTH = 6
        private const val DATA_RESPONSE_LENGTH = 6
        private const val SEND_RATE_HZ = 120L
        private const val SEND_INTERVAL_NANOS = 1_000_000_000L / SEND_RATE_HZ
        private const val BEGIN_TIMEOUT_SECONDS = 20L
        private const val END_TIMEOUT_SECONDS = 600L

        internal fun sha256(data: ByteArray): ByteArray = MessageDigest.getInstance("SHA-256").digest(data)

        private fun littleEndianUShort(
            data: ByteArray,
            offset: Int,
        ): UShort =
            ((data[offset].toInt() and 0xFF) or ((data[offset + 1].toInt() and 0xFF) shl 8)).toUShort()

        private fun littleEndianUInt(
            data: ByteArray,
            offset: Int,
        ): UInt =
            ((data[offset].toUInt() and 0xFFu) or
                ((data[offset + 1].toUInt() and 0xFFu) shl 8) or
                ((data[offset + 2].toUInt() and 0xFFu) shl 16) or
                ((data[offset + 3].toUInt() and 0xFFu) shl 24))
    }
}
