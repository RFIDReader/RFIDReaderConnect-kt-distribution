package com.bypratham.rfidreaderconnect

import kotlinx.coroutines.delay as coroutinesDelay
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.IOException
import java.net.HttpURLConnection
import java.net.MalformedURLException
import java.net.NoRouteToHostException
import java.net.SocketTimeoutException
import java.net.URI
import java.net.URL
import java.net.UnknownHostException

/** Failures produced by [performHttpRequest], matching the Apple SDK taxonomy. */
internal sealed class HTTPRequestError(
    message: String,
    cause: Throwable? = null,
) : IOException(message, cause) {
    data object Timeout : HTTPRequestError("HTTP request timed out")

    data object NoInternet : HTTPRequestError("No internet connection")

    data class ServerError(val statusCode: Int) : HTTPRequestError("Server returned HTTP $statusCode")

    data object InvalidURL : HTTPRequestError("Invalid URL")

    class OtherError(cause: Throwable) : HTTPRequestError(cause.message ?: "HTTP request failed", cause)
}

/** The response metadata returned alongside the raw body by [performHttpRequest]. */
internal data class HTTPResponse(
    val statusCode: Int,
    val headers: Map<String, List<String>>,
)

/** Removes URL schemes, ports, paths, and trailing slashes from a reader host. */
internal fun sanitizeHost(host: String): String {
    val prefixed =
        if (
            host.startsWith("http://") ||
            host.startsWith("https://") ||
            host.startsWith("ws://") ||
            host.startsWith("wss://")
        ) {
            host
        } else {
            "http://$host"
        }
    return runCatching { URI(prefixed).host ?: host }.getOrDefault(host)
}

/** Removes optional leading/trailing colons while preserving Apple's permissive validation. */
internal fun sanitizePort(port: String): String = port.trim(':')

/**
 * Performs a small raw HTTP request and returns response bytes for every status below 500.
 * Server-side 5xx responses are surfaced as [HTTPRequestError.ServerError].
 */
internal suspend fun performHttpRequest(
    urlStr: String,
    method: String,
    contentType: String? = null,
    body: ByteArray? = null,
    timeoutMillis: Int? = 200,
): Pair<ByteArray, HTTPResponse> =
    withContext(Dispatchers.IO) {
        val url =
            try {
                URL(urlStr)
            } catch (_: MalformedURLException) {
                throw HTTPRequestError.InvalidURL
            }
        val connection =
            try {
                (url.openConnection() as HttpURLConnection).apply {
                    requestMethod = method
                    timeoutMillis?.let {
                        connectTimeout = it
                        readTimeout = it
                    }
                    contentType?.let { setRequestProperty("Content-Type", it) }
                    body?.let {
                        doOutput = true
                        outputStream.use { stream -> stream.write(it) }
                    }
                }
            } catch (error: Throwable) {
                throw error.toHTTPRequestError()
            }

        try {
            val statusCode = connection.responseCode
            val responseBody =
                (if (statusCode >= 400) connection.errorStream else connection.inputStream)
                    ?.use { it.readBytes() }
                    ?: ByteArray(0)
            if (statusCode >= 500) throw HTTPRequestError.ServerError(statusCode)
            val headers = connection.headerFields.filterKeys { it != null }
            responseBody to HTTPResponse(statusCode, headers)
        } catch (error: HTTPRequestError) {
            throw error
        } catch (error: Throwable) {
            throw error.toHTTPRequestError()
        } finally {
            connection.disconnect()
        }
    }

private fun Throwable.toHTTPRequestError(): HTTPRequestError =
    when (this) {
        is SocketTimeoutException -> HTTPRequestError.Timeout
        is UnknownHostException, is NoRouteToHostException -> HTTPRequestError.NoInternet
        is MalformedURLException -> HTTPRequestError.InvalidURL
        else -> HTTPRequestError.OtherError(this)
    }

internal const val MSG_CRC_INIT: Int = 0xFFFF
internal const val MSG_CCITT_CRC_POLY: Int = 0x1021

private fun crcCalcCrc8(
    crcReg: Int,
    poly: Int,
    u8Data: Int,
): Int {
    var reg = crcReg
    var dcdBitMask = 0x80
    repeat(8) {
        val xorFlag = reg and 0x8000
        reg = (reg shl 1) and 0xFFFF
        val bit = if ((u8Data and dcdBitMask) == dcdBitMask) 1 else 0
        reg = reg or bit
        if (xorFlag != 0) {
            reg = reg xor poly
        }
        dcdBitMask = dcdBitMask shr 1
    }
    return reg
}

/** CCITT CRC-16 with the iOS "skip byte 0" quirk. */
internal fun calcCRC(msg: ByteArray): UShort {
    var reg = MSG_CRC_INIT
    for (i in 1 until msg.size) {
        reg = crcCalcCrc8(reg, MSG_CCITT_CRC_POLY, msg[i].toInt() and 0xFF)
    }
    return (reg and 0xFFFF).toUShort()
}

/** Sum-of-bytes mod 256, used for SubCommand CRC. */
internal fun getSubCRC(data: ByteArray): UByte {
    var sum = 0
    for (b in data) {
        sum += (b.toInt() and 0xFF)
    }
    return (sum and 0xFF).toUByte()
}

/** Big-endian byte array of [length] bytes, matching iOS `Int2Bytes`. */
internal fun int2Bytes(
    value: Long,
    length: Int,
): ByteArray {
    val bytes = ByteArray(length)
    for (i in 0 until length) {
        bytes[i] = ((value shr (8 * (length - 1 - i))) and 0xFF).toByte()
    }
    return bytes
}

internal fun int2Bytes(
    value: Int,
    length: Int,
): ByteArray = int2Bytes(value.toLong() and 0xFFFFFFFFL, length)

internal fun int2Bytes(
    value: UInt,
    length: Int,
): ByteArray = int2Bytes(value.toLong(), length)

internal fun int2Bytes(
    value: UShort,
    length: Int,
): ByteArray = int2Bytes(value.toLong(), length)

internal fun int2Bytes(
    value: UByte,
    length: Int,
): ByteArray = int2Bytes(value.toLong(), length)

private val HEX_DIGITS = "0123456789ABCDEF".toCharArray()

/** Uppercase hex, no separators. */
internal fun ByteArray.toHex(): String {
    val sb = StringBuilder(size * 2)
    for (b in this) {
        val v = b.toInt() and 0xFF
        sb.append(HEX_DIGITS[v ushr 4])
        sb.append(HEX_DIGITS[v and 0x0F])
    }
    return sb.toString()
}

/** iOS-parity helper for printing data as hex. */
internal fun dataAsHex(data: ByteArray): String = data.toHex()

/** Coroutine-friendly delay by seconds, mirroring iOS `delay(_:)`. */
internal suspend fun delay(seconds: Double) {
    coroutinesDelay((seconds * 1000).toLong())
}
