package com.bypratham.rfidreaderconnect

import android.content.Context
import android.os.Build
import android.util.Log

/** Reader, host-app, and Android platform metadata collected for an analytics record. */
internal data class ReaderAnalyticsData(
    val serialNumber: String,
    val modelNumber: String,
    val appName: String,
    val appVersion: String,
    val bundleId: String,
    val deviceModel: String,
    val osVersion: String,
)

/** Minimal analytics collector equivalent to Apple's `Analytics.record`. */
internal object Analytics {
    fun record(
        context: Context,
        modelNumber: String,
        serialNumber: String,
    ): ReaderAnalyticsData {
        val packageManager = context.packageManager
        val packageName = context.packageName
        val packageInfo = packageManager.getPackageInfo(packageName, 0)
        val applicationInfo = packageInfo.applicationInfo ?: context.applicationInfo
        val buildNumber =
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                packageInfo.longVersionCode
            } else {
                @Suppress("DEPRECATION")
                packageInfo.versionCode.toLong()
            }
        val data =
            ReaderAnalyticsData(
                serialNumber = serialNumber,
                modelNumber = modelNumber,
                appName = packageManager.getApplicationLabel(applicationInfo).toString(),
                appVersion = packageInfo.versionName ?: "0",
                bundleId = packageName,
                deviceModel = "${Build.MANUFACTURER} ${Build.MODEL}".trim(),
                osVersion = Build.VERSION.RELEASE,
            )
        Log.d(
            "Analytics-record",
            "${data.appName}, ${data.appVersion}, $buildNumber, " +
                "${data.bundleId}, ${data.deviceModel}, ${data.osVersion}, $modelNumber, $serialNumber",
        )
        return data
    }
}
