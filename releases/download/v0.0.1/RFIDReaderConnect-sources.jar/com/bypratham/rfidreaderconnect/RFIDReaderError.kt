package com.bypratham.rfidreaderconnect

/** SDK-facing errors. Mirrors the iOS `RFIDReaderError` cases 1:1. */
sealed class RFIDReaderError(message: String) : Exception(message) {
    class Unimplemented(description: String) : RFIDReaderError(description)

    class TransportNotReady(description: String) : RFIDReaderError(description)

    class ReaderError(
        val cmd: String? = null,
        description: String,
    ) : RFIDReaderError(description)
}
