package com.bypratham.rfidreaderconnect.webbridge

import com.bypratham.rfidreaderconnect.RFIDReaderAntennaPort
import com.bypratham.rfidreaderconnect.RFIDReaderCommMode
import com.bypratham.rfidreaderconnect.RFIDReaderConfiguration
import com.bypratham.rfidreaderconnect.RFIDReaderNotificationType
import com.bypratham.rfidreaderconnect.RFIDReaderQ
import com.bypratham.rfidreaderconnect.RFIDReaderRFMode
import com.bypratham.rfidreaderconnect.RFIDReaderRegion
import com.bypratham.rfidreaderconnect.RFIDReaderSession
import com.bypratham.rfidreaderconnect.RFIDReaderTagMetadata
import com.bypratham.rfidreaderconnect.RFIDReaderTagSingulationData
import com.bypratham.rfidreaderconnect.RFIDReaderTagSingulationFlag
import com.bypratham.rfidreaderconnect.RFIDReaderTarget
import com.bypratham.rfidreaderconnect.RFIDTagMemoryBank
import org.json.JSONArray
import org.json.JSONObject

/** Errors thrown while parsing JS command arguments. */
internal class RFIDBridgeError(val bridgeMessage: String) : Exception(bridgeMessage)

/**
 * Typed parsing helpers for JS-supplied arguments. Enum-valued arguments accept
 * either their JS-facing case name (e.g. `"FCC"`, `"epc"`) or their numeric
 * raw value.
 */
internal object Args {
    fun optString(
        args: JSONObject,
        key: String,
    ): String? = if (args.isNull(key)) null else args.optString(key, "").takeIf { it.isNotEmpty() }

    fun optInt(
        args: JSONObject,
        key: String,
    ): Int? = if (args.isNull(key) || !args.has(key)) null else args.optInt(key)

    fun optLong(
        args: JSONObject,
        key: String,
    ): Long? = if (args.isNull(key) || !args.has(key)) null else args.optLong(key)

    fun optBool(
        args: JSONObject,
        key: String,
    ): Boolean? = if (args.isNull(key) || !args.has(key)) null else args.optBoolean(key)

    fun string(
        args: JSONObject,
        key: String,
    ): String = optString(args, key) ?: throw RFIDBridgeError("Missing or invalid string argument '$key'.")

    fun bool(
        args: JSONObject,
        key: String,
    ): Boolean = optBool(args, key) ?: throw RFIDBridgeError("Missing or invalid boolean argument '$key'.")

    fun uint8(
        args: JSONObject,
        key: String,
    ): UByte {
        val n = optInt(args, key) ?: throw RFIDBridgeError("Missing or out-of-range UInt8 argument '$key'.")
        if (n < 0 || n > 0xFF) throw RFIDBridgeError("Missing or out-of-range UInt8 argument '$key'.")
        return n.toUByte()
    }

    fun uint16(
        args: JSONObject,
        key: String,
    ): UShort {
        val n = optInt(args, key) ?: throw RFIDBridgeError("Missing or out-of-range UInt16 argument '$key'.")
        if (n < 0 || n > 0xFFFF) throw RFIDBridgeError("Missing or out-of-range UInt16 argument '$key'.")
        return n.toUShort()
    }

    fun uint32(
        args: JSONObject,
        key: String,
    ): UInt {
        val n = optLong(args, key) ?: throw RFIDBridgeError("Missing or out-of-range UInt32 argument '$key'.")
        if (n < 0 || n > 0xFFFFFFFFL) throw RFIDBridgeError("Missing or out-of-range UInt32 argument '$key'.")
        return n.toUInt()
    }

    fun optionalUInt8(
        args: JSONObject,
        key: String,
    ): UByte? {
        val n = optInt(args, key) ?: return null
        if (n < 0 || n > 0xFF) return null
        return n.toUByte()
    }

    fun optionalUInt32(
        args: JSONObject,
        key: String,
    ): UInt? {
        val n = optLong(args, key) ?: return null
        if (n < 0 || n > 0xFFFFFFFFL) return null
        return n.toUInt()
    }

    fun data(
        args: JSONObject,
        key: String,
    ): ByteArray {
        val hex = optString(args, key) ?: throw RFIDBridgeError("Missing or invalid hex string argument '$key'.")
        return dataFromHex(hex) ?: throw RFIDBridgeError("Missing or invalid hex string argument '$key'.")
    }

    fun optionalData(
        args: JSONObject,
        key: String,
    ): ByteArray? {
        val hex = optString(args, key) ?: return null
        return dataFromHex(hex)
    }

    fun dataFromHex(raw: String): ByteArray? {
        val clean =
            raw.replace("0x", "", ignoreCase = true)
                .replace(" ", "")
        if (clean.isEmpty() || clean.length % 2 != 0) return null
        val bytes = ByteArray(clean.length / 2)
        for (i in bytes.indices) {
            val hi = Character.digit(clean[i * 2], 16)
            val lo = Character.digit(clean[i * 2 + 1], 16)
            if (hi == -1 || lo == -1) return null
            bytes[i] = ((hi shl 4) or lo).toByte()
        }
        return bytes
    }

    fun commMode(args: JSONObject): RFIDReaderCommMode {
        val map =
            mapOf(
                "ble" to RFIDReaderCommMode.BLE,
                "wifiAP" to RFIDReaderCommMode.WIFI_AP,
                "wifiSTA" to RFIDReaderCommMode.WIFI_STA,
                "usb" to RFIDReaderCommMode.USB,
            )
        val name = optString(args, "commMode")
        if (name != null) map[name]?.let { return it }
        val raw = optInt(args, "commMode")
        if (raw != null && raw in 0..0xFF) {
            RFIDReaderCommMode.fromRaw(raw.toUByte())?.let { return it }
        }
        throw RFIDBridgeError("Missing or invalid 'commMode'.")
    }

    fun notificationType(args: JSONObject): RFIDReaderNotificationType {
        val map =
            mapOf(
                "none" to RFIDReaderNotificationType.NONE,
                "led" to RFIDReaderNotificationType.LED,
                "beep" to RFIDReaderNotificationType.BEEP,
                "ledAndBeep" to RFIDReaderNotificationType.LED_AND_BEEP,
                "vibrate" to RFIDReaderNotificationType.VIBRATE,
                "ledAndVibrate" to RFIDReaderNotificationType.LED_AND_VIBRATE,
                "beepAndVibrate" to RFIDReaderNotificationType.BEEP_AND_VIBRATE,
                "ledBeepAndVibrate" to RFIDReaderNotificationType.LED_BEEP_AND_VIBRATE,
            )
        val name = optString(args, "notificationType")
        if (name != null) map[name]?.let { return it }
        val raw = optInt(args, "notificationType")
        if (raw != null && raw in 0..0xFF) {
            RFIDReaderNotificationType.fromRaw(raw.toUByte())?.let { return it }
        }
        throw RFIDBridgeError("Missing or invalid 'notificationType'.")
    }

    fun region(args: JSONObject): RFIDReaderRegion {
        val name = optString(args, "region")
        if (name != null) RFIDReaderRegion.values().firstOrNull { it.name == name }?.let { return it }
        val raw = optInt(args, "region")
        if (raw != null && raw in 0..0xFF) {
            RFIDReaderRegion.fromRaw(raw.toUByte())?.let { return it }
        }
        throw RFIDBridgeError("Missing or invalid 'region'.")
    }

    fun session(args: JSONObject): RFIDReaderSession {
        val map =
            mapOf(
                "zero" to RFIDReaderSession.ZERO,
                "one" to RFIDReaderSession.ONE,
                "two" to RFIDReaderSession.TWO,
                "three" to RFIDReaderSession.THREE,
                "0" to RFIDReaderSession.ZERO,
                "1" to RFIDReaderSession.ONE,
                "2" to RFIDReaderSession.TWO,
                "3" to RFIDReaderSession.THREE,
            )
        val name = optString(args, "session")
        if (name != null) map[name]?.let { return it }
        val raw = optInt(args, "session")
        if (raw != null && raw in 0..0xFF) {
            RFIDReaderSession.fromRaw(raw.toUByte())?.let { return it }
        }
        throw RFIDBridgeError("Missing or invalid 'session'.")
    }

    fun target(args: JSONObject): RFIDReaderTarget {
        return when ((optString(args, "target") ?: "").lowercase()) {
            "a" -> RFIDReaderTarget.A
            "b" -> RFIDReaderTarget.B
            "ab" -> RFIDReaderTarget.AB
            "ba" -> RFIDReaderTarget.BA
            else -> throw RFIDBridgeError("Invalid 'target'. Expected one of a, b, ab, ba.")
        }
    }

    fun rfMode(args: JSONObject): RFIDReaderRFMode {
        val map =
            mapOf(
                "one" to RFIDReaderRFMode.ONE,
                "three" to RFIDReaderRFMode.THREE,
                "five" to RFIDReaderRFMode.FIVE,
                "seven" to RFIDReaderRFMode.SEVEN,
                "eleven" to RFIDReaderRFMode.ELEVEN,
                "twelve" to RFIDReaderRFMode.TWELVE,
                "thirteen" to RFIDReaderRFMode.THIRTEEN,
                "fifteen" to RFIDReaderRFMode.FIFTEEN,
                "oneZeroThree" to RFIDReaderRFMode.ONE_ZERO_THREE,
                "oneTwoZero" to RFIDReaderRFMode.ONE_TWO_ZERO,
                "threeFourFive" to RFIDReaderRFMode.THREE_FOUR_FIVE,
            )
        val name = optString(args, "mode")
        if (name != null) map[name]?.let { return it }
        val raw = optInt(args, "mode")
        if (raw != null && raw in 0..0xFF) {
            RFIDReaderRFMode.fromRaw(raw.toUByte())?.let { return it }
        }
        throw RFIDBridgeError("Missing or invalid 'mode'.")
    }

    fun readerConfiguration(args: JSONObject): RFIDReaderConfiguration {
        val map =
            mapOf(
                "useAntennaPortAsUniqueIdentifier" to RFIDReaderConfiguration.USE_ANTENNA_PORT_AS_UNIQUE_IDENTIFIER,
                "recordMaximumRSSIValue" to RFIDReaderConfiguration.RECORD_MAXIMUM_RSSI_VALUE,
                "useBankDataAsUniqueIdentifier" to RFIDReaderConfiguration.USE_BANK_DATA_AS_UNIQUE_IDENTIFIER,
            )
        val name = optString(args, "readerConfiguration")
        if (name != null) map[name]?.let { return it }
        val raw = optInt(args, "readerConfiguration")
        if (raw != null && raw in 0..0xFF) {
            RFIDReaderConfiguration.fromRaw(raw.toUByte())?.let { return it }
        }
        throw RFIDBridgeError("Missing or invalid 'readerConfiguration'.")
    }

    fun q(args: JSONObject): RFIDReaderQ? {
        val mode = optString(args, "mode")
        if (mode != null) {
            when (mode.lowercase()) {
                "dynamic" -> return RFIDReaderQ.DynamicQ
                "static" -> {
                    val v = optInt(args, "value") ?: 0
                    return RFIDReaderQ.StaticQ(v.coerceIn(0, 0xFF).toUByte())
                }
            }
        }
        val v = optInt(args, "value") ?: return null
        return RFIDReaderQ.StaticQ(v.coerceIn(0, 0xFF).toUByte())
    }

    fun memoryBank(args: JSONObject): RFIDTagMemoryBank? =
        try {
            requiredMemoryBank(args)
        } catch (_: RFIDBridgeError) {
            null
        }

    fun requiredMemoryBank(args: JSONObject): RFIDTagMemoryBank {
        val map =
            mapOf(
                "reserved" to RFIDTagMemoryBank.RESERVED,
                "epc" to RFIDTagMemoryBank.EPC,
                "tid" to RFIDTagMemoryBank.TID,
                "user" to RFIDTagMemoryBank.USER,
            )
        val name = optString(args, "memoryBank")
        if (name != null) map[name]?.let { return it }
        val raw = optInt(args, "memoryBank")
        if (raw != null && raw in 0..0xFF) {
            RFIDTagMemoryBank.fromRaw(raw.toUByte())?.let { return it }
        }
        throw RFIDBridgeError("Missing or invalid 'memoryBank'.")
    }

    fun password(args: JSONObject): UInt? = optionalUInt32(args, "password")

    fun singulationFlag(args: JSONObject): RFIDReaderTagSingulationFlag? {
        val map =
            mapOf(
                "none" to RFIDReaderTagSingulationFlag.NONE,
                "filterEPC" to RFIDReaderTagSingulationFlag.FILTER_EPC,
                "filterTID" to RFIDReaderTagSingulationFlag.FILTER_TID,
                "filterUserBank" to RFIDReaderTagSingulationFlag.FILTER_USER_BANK,
                "filterEPCContent" to RFIDReaderTagSingulationFlag.FILTER_EPC_CONTENT,
                "filterMultipleTags" to RFIDReaderTagSingulationFlag.FILTER_MULTIPLE_TAGS,
                "setInversionFlag" to RFIDReaderTagSingulationFlag.SET_INVERSION_FLAG,
                "filterMoreTags" to RFIDReaderTagSingulationFlag.FILTER_MORE_TAGS,
            )
        val name = optString(args, "tagSingulationFlag")
        if (name != null) return map[name]
        val raw = optInt(args, "tagSingulationFlag") ?: return null
        return RFIDReaderTagSingulationFlag.fromRaw(raw.coerceIn(0, 0xFF).toUByte())
    }

    fun singulationData(args: JSONObject): RFIDReaderTagSingulationData? {
        val dict = args.optJSONObject("tagSingulationData") ?: return null
        val lengthHex = dict.optString("selectDataLength", "")
        val dataHex = dict.optString("selectData", "")
        if (lengthHex.isEmpty() || dataHex.isEmpty()) return null
        val length = dataFromHex(lengthHex) ?: return null
        val data = dataFromHex(dataHex) ?: return null
        val addressHex = if (dict.isNull("selectAddress")) null else dict.optString("selectAddress", "").ifEmpty { null }
        val address = addressHex?.let { dataFromHex(it) }
        return RFIDReaderTagSingulationData(
            selectAddress = address,
            selectDataLength = length,
            selectData = data,
        )
    }

    fun metadata(args: JSONObject): List<RFIDReaderTagMetadata>? {
        val raw = args.optJSONArray("metadata") ?: return null
        val map =
            mapOf(
                "none" to RFIDReaderTagMetadata.NONE,
                "returnReadCount" to RFIDReaderTagMetadata.RETURN_READ_COUNT,
                "returnRSSI" to RFIDReaderTagMetadata.RETURN_RSSI,
                "returnAntennaID" to RFIDReaderTagMetadata.RETURN_ANTENNA_ID,
                "returnFrequency" to RFIDReaderTagMetadata.RETURN_FREQUENCY,
                "returnTimestamp" to RFIDReaderTagMetadata.RETURN_TIMESTAMP,
                "returnPhaseValue" to RFIDReaderTagMetadata.RETURN_PHASE_VALUE,
                "returnDataLen" to RFIDReaderTagMetadata.RETURN_DATA_LEN,
            )
        val out = mutableListOf<RFIDReaderTagMetadata>()
        for (i in 0 until raw.length()) {
            val v = raw.opt(i) ?: continue
            when (v) {
                is String -> map[v]?.let(out::add)
                is Int -> RFIDReaderTagMetadata.fromRaw(v.coerceIn(0, 0xFFFF).toUShort())?.let(out::add)
                is Long -> RFIDReaderTagMetadata.fromRaw(v.coerceIn(0, 0xFFFF).toInt().toUShort())?.let(out::add)
                else -> Unit
            }
        }
        return out.ifEmpty { null }
    }

    fun antennaPorts(args: JSONObject): List<RFIDReaderAntennaPort> {
        val raw =
            args.optJSONArray("antennaPorts")
                ?: throw RFIDBridgeError("Missing 'antennaPorts' array.")
        val out = mutableListOf<RFIDReaderAntennaPort>()
        for (i in 0 until raw.length()) {
            val port =
                raw.optJSONObject(i)
                    ?: throw RFIDBridgeError("Each antenna port needs 'number', 'readPower', 'writePower'.")
            val number = port.optInt("number", -1)
            val readPower = port.optInt("readPower", -1)
            val writePower = port.optInt("writePower", -1)
            if (number < 0 || readPower < 0 || writePower < 0) {
                throw RFIDBridgeError("Each antenna port needs 'number', 'readPower', 'writePower'.")
            }
            out +=
                RFIDReaderAntennaPort(
                    number = number.coerceIn(0, 0xFF).toUByte(),
                    readPower = readPower.coerceIn(0, 0xFFFF).toUShort(),
                    writePower = writePower.coerceIn(0, 0xFFFF).toUShort(),
                )
        }
        return out
    }

    /** Convenience so callers can pass either a `String[]` or JSON array of hex strings. */
    @Suppress("unused")
    fun stringArray(
        args: JSONObject,
        key: String,
    ): JSONArray? = args.optJSONArray(key)
}
