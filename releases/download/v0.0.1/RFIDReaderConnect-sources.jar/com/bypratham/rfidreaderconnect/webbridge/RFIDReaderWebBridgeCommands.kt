package com.bypratham.rfidreaderconnect.webbridge

import android.content.Context
import com.bypratham.rfidreaderconnect.RFIDReader
import com.bypratham.rfidreaderconnect.RFIDReaderModel
import com.bypratham.rfidreaderconnect.transport.TransportType
import com.bypratham.rfidreaderconnect.transport.WiFiTransportMode
import org.json.JSONObject

/** Dispatches JS command names to matching `RFIDReader` calls. */
internal object RFIDReaderWebBridgeCommands {
    /**
     * Handles a JS command that has already been parsed into `method` + `args`.
     *
     * Connection lifecycle commands (`connect`, `disconnect`, `getState`,
     * `startDeviceScan`, `stopDeviceScan`) are handled by the bridge itself.
     * All other commands require an active [RFIDReader].
     */
    fun dispatch(
        bridge: RFIDReaderWebBridge,
        method: String,
        args: JSONObject,
        requestId: String?,
    ) {
        bridge.attachIfNeeded()

        when (method) {
            "connect" -> {
                bridge.handleConnect(args, requestId)
                return
            }
            "disconnect" -> {
                bridge.handleDisconnect(requestId)
                return
            }
            "startDeviceScan" -> {
                bridge.startDeviceScan(requestId)
                return
            }
            "stopDeviceScan" -> {
                bridge.stopDeviceScan(requestId)
                return
            }
            "getState" -> {
                val reader = bridge.reader
                val payload = JSONObject()
                payload.put("isConnected", reader?.isConnected ?: false)
                payload.put("isScanning", reader?.isScanning ?: false)
                reader?.model?.rawValue?.let { payload.put("model", it) }
                reader?.name?.let { payload.put("name", it) }
                reader?.serialNumber?.let { payload.put("serialNumber", it) }
                reader?.version?.let { payload.put("version", it) }
                bridge.resolve(requestId, payload)
                return
            }
        }

        val reader =
            bridge.reader ?: run {
                bridge.reject(requestId, "No active reader. Call connect() first.")
                return
            }

        try {
            route(bridge, method, args, reader, requestId)
        } catch (bridgeError: RFIDBridgeError) {
            bridge.reject(requestId, bridgeError.bridgeMessage)
        } catch (t: Throwable) {
            bridge.reject(requestId, t.message ?: t.toString())
        }
    }

    @Suppress("LongMethod", "CyclomaticComplexMethod")
    private fun route(
        bridge: RFIDReaderWebBridge,
        method: String,
        args: JSONObject,
        reader: RFIDReader,
        requestId: String?,
    ) {
        when (method) {
            "getCommMode" -> reader.getCommMode()
            "setCommMode" -> reader.setCommMode(Args.commMode(args))
            "getNetworkSSID" -> reader.getNetworkSSID()
            "setNetworkSSID" -> reader.setNetworkSSID(Args.string(args, "ssid"))
            "getNetworkPassword" -> reader.getNetworkPassword()
            "setNetworkPassword" -> reader.setNetworkPassword(Args.string(args, "password"))
            "getAlertNotification" -> reader.getAlertNotification()
            "setAlertNotification" -> reader.setAlertNotification(Args.notificationType(args))
            "getVersion" -> reader.getVersion()
            "getSerialNumber" -> reader.getSerialNumber()
            "getDeviceName" -> reader.getDeviceName()
            "setDeviceName" -> reader.setDeviceName(Args.string(args, "deviceName"))
            "getModel" -> reader.getModel()
            "getIPv4" -> reader.getIPv4()
            "getMac" -> reader.getMac()
            "getBatterySoc" -> reader.getBatterySoc()
            "getBatterySoh" -> reader.getBatterySoh()
            "getBatteryCycles" -> reader.getBatteryCycles()
            "factoryReset" -> reader.factoryReset()
            "reboot" -> reader.reboot()
            "performOTA" -> reader.performOTA(Args.string(args, "version"))

            "sendRawCmd" ->
                reader.sendRawCmd(
                    cmd = Args.data(args, "cmd"),
                    calculateCRC = Args.optBool(args, "calculateCRC") ?: true,
                )
            "getHWVersion" -> reader.getHWVersion()
            "getHWSerialNumber" -> reader.getHWSerialNumber()
            "bootFirmware" -> reader.bootFirmware()

            "singleTagInventory" ->
                reader.singleTagInventory(
                    timeout = Args.uint16(args, "timeout"),
                    metadata = Args.metadata(args),
                    tagSingulationFlag = Args.singulationFlag(args),
                    tagSingulationData = Args.singulationData(args),
                )
            "startSyncInventory" -> reader.startSyncInventory()
            "getTagBuffer" -> reader.getTagBuffer()
            "startAsyncInventory" ->
                reader.startAsyncInventory(
                    powerSave = Args.optBool(args, "powerSave"),
                    metadata = Args.metadata(args),
                    password = Args.password(args),
                    tsFlag = Args.singulationFlag(args),
                    tsData = Args.singulationData(args),
                    memoryBank = Args.memoryBank(args),
                    readAddress = Args.optionalUInt32(args, "readAddress"),
                    wordCount = Args.optionalUInt8(args, "wordCount"),
                )
            "stopAsyncInventory" -> reader.stopAsyncInventory()
            "startEXAsyncInventory" -> reader.startEXAsyncInventory(metadata = Args.metadata(args))
            "stopEXAsyncInventory" -> reader.stopEXAsyncInventory()

            "writeTagEPC" ->
                reader.writeTagEPC(
                    tagEPC = Args.data(args, "tagEPC"),
                    timeout = Args.uint16(args, "timeout"),
                    password = Args.password(args),
                    tagSingulationFlag = Args.singulationFlag(args),
                    tagSingulationData = Args.singulationData(args),
                )
            "writeTag" -> reader.writeTag(Args.data(args, "data"))
            "lockTag" -> reader.lockTag()
            "killTag" -> reader.killTag()
            "readTagMemoryBank" -> {
                val tag =
                    reader.readTagMemoryBank(
                        timeout = Args.uint16(args, "timeout"),
                        tagSingulationFlag = Args.singulationFlag(args),
                        metadata = Args.metadata(args),
                        memoryBank = Args.requiredMemoryBank(args),
                        readAddress = Args.uint32(args, "readAddress"),
                        wordCount = Args.uint8(args, "wordCount"),
                        password = Args.password(args),
                        tagSingulationData = Args.singulationData(args),
                    )
                bridge.resolve(requestId, tag?.let(RFIDReaderWebBridgeSerialization::serializeTag))
                return
            }

            "getAntennaPort" -> reader.getAntennaPort()
            "setAntennaPort" ->
                reader.setAntennaPort(
                    antennaPorts = Args.antennaPorts(args),
                    permanent = Args.optBool(args, "permanent"),
                )
            "getFreqHopping" -> reader.getFreqHopping()
            "setFreqHopping" -> reader.setFreqHopping(region = Args.region(args))
            "getRegion" -> reader.getRegion()
            "setRegion" ->
                reader.setRegion(
                    region = Args.region(args),
                    permanent = Args.optBool(args, "permanent"),
                )
            "getTemperature" -> reader.getTemperature()
            "getReaderConfiguration" -> reader.getReaderConfiguration(Args.readerConfiguration(args))
            "setReaderConfiguration" ->
                reader.setReaderConfiguration(
                    readerConfiguration = Args.readerConfiguration(args),
                    enable = Args.bool(args, "enable"),
                )
            "getSession" -> reader.getSession()
            "setSession" ->
                reader.setSession(
                    session = Args.session(args),
                    permanent = Args.optBool(args, "permanent"),
                )
            "getTarget" -> reader.getTarget()
            "setTarget" ->
                reader.setTarget(
                    target = Args.target(args),
                    permanent = Args.optBool(args, "permanent"),
                )
            "getRFMode" -> reader.getRFMode()
            "setRFMode" ->
                reader.setRFMode(
                    mode = Args.rfMode(args),
                    permanent = Args.optBool(args, "permanent"),
                )
            "getQ" -> reader.getQ()
            "setQ" ->
                reader.setQ(
                    q = Args.q(args),
                    permanent = Args.optBool(args, "permanent"),
                )

            else -> {
                bridge.reject(requestId, "Unknown method: $method")
                return
            }
        }
        bridge.resolve(requestId, null)
    }

    /** Builds a [TransportType] from the JS `transport` configuration dictionary. */
    fun parseTransport(
        context: Context,
        args: JSONObject,
    ): TransportType {
        val type = (Args.optString(args, "type") ?: "").lowercase()
        return when (type) {
            "ble" -> {
                val identifier =
                    Args.optString(args, "identifier")
                        ?: throw RFIDBridgeError("BLE transport requires an 'identifier' (MAC address).")
                TransportType.Ble(
                    context = context,
                    identifier = identifier,
                    connectionTimeout = (Args.optLong(args, "connectionTimeout") ?: 30_000L),
                    maxRetries = Args.optInt(args, "maxRetries"),
                    retryInterval = Args.optInt(args, "retryInterval"),
                    debug = Args.optBool(args, "debug") ?: false,
                )
            }
            "wifi" -> {
                val host =
                    Args.optString(args, "host")
                        ?: throw RFIDBridgeError("WiFi transport requires a 'host'.")
                val mode =
                    if ((Args.optString(args, "mode") ?: "").lowercase() == "udp") {
                        WiFiTransportMode.UDP
                    } else {
                        WiFiTransportMode.TCP
                    }
                TransportType.WiFi(
                    host = host,
                    httpPort = Args.optString(args, "httpPort") ?: "80",
                    tcpPort = Args.optString(args, "tcpPort") ?: "81",
                    udpPort = Args.optString(args, "udpPort") ?: "82",
                    mode = mode,
                    maxRetries = Args.optInt(args, "maxRetries"),
                    retryInterval = Args.optInt(args, "retryInterval"),
                    debug = Args.optBool(args, "debug") ?: false,
                )
            }
            "usb" ->
                TransportType.Usb(
                    context = context,
                    portName = Args.optString(args, "portName"),
                    debug = Args.optBool(args, "debug") ?: false,
                )
            else -> throw RFIDBridgeError("Unsupported transport type: '$type'. Use 'ble', 'wifi' or 'usb'.")
        }
    }

    /** Parses the top-level `model` field from a JS `connect` payload. */
    fun parseModel(args: JSONObject): RFIDReaderModel {
        val raw = Args.optString(args, "model")
        val model = raw?.let { RFIDReaderModel.fromRaw(it) }
        return model
            ?: throw RFIDBridgeError(
                "Missing or invalid 'model'. Expected one of the RFIDReaderModel raw values, e.g. 'MARK3-HH7'.",
            )
    }
}
