package com.bypratham.rfidreaderconnect.webbridge

/**
 * JavaScript client library injected into every bridged [android.webkit.WebView].
 *
 * Exposes a promise + event-listener API at `window.RFIDReader`. The shape
 * mirrors the iOS `RFIDReaderBridgeScript` 1:1 so cross-platform mini programs
 * do not need any conditional code. The only difference is the native handler
 * invocation: Android `@JavascriptInterface` receives strings, so we
 * `JSON.stringify` the payload before posting.
 */
object RFIDReaderBridgeScript {
    /** Returns the JS source, parameterised by the native message handler name. */
    fun source(handlerName: String): String =
        """
        (function () {
          if (window.RFIDReader && window.RFIDReader.__installed) { return; }

          var HANDLER = "$handlerName";
          var pending = {};
          var listeners = {};
          var counter = 0;

          function nextId() {
            counter += 1;
            return "req_" + Date.now() + "_" + counter;
          }

          function post(method, args) {
            return new Promise(function (resolve, reject) {
              var requestId = nextId();
              pending[requestId] = { resolve: resolve, reject: reject };
              try {
                if (!window[HANDLER] || typeof window[HANDLER].postMessage !== "function") {
                  throw new Error("RFID native bridge is not available.");
                }
                window[HANDLER].postMessage(JSON.stringify({
                  method: method,
                  args: args || {},
                  requestId: requestId
                }));
              } catch (e) {
                delete pending[requestId];
                reject(e);
              }
            });
          }

          window.__rfidBridgeResolve = function (payload) {
            var entry = pending[payload.requestId];
            if (!entry) { return; }
            delete pending[payload.requestId];
            if (payload.ok) {
              entry.resolve(payload.result);
            } else {
              entry.reject(new Error(payload.error || "Unknown error"));
            }
          };

          window.__rfidBridgeEmit = function (payload) {
            var cbs = listeners[payload.event];
            if (!cbs) { return; }
            cbs.slice().forEach(function (cb) {
              try { cb(payload.data); } catch (e) { /* swallow listener errors */ }
            });
          };

          var api = {
            __installed: true,

            on: function (event, cb) {
              (listeners[event] = listeners[event] || []).push(cb);
              return function () { api.off(event, cb); };
            },
            off: function (event, cb) {
              var cbs = listeners[event];
              if (!cbs) { return; }
              listeners[event] = cbs.filter(function (fn) { return fn !== cb; });
            },
            once: function (event, cb) {
              var remove = api.on(event, function (data) { remove(); cb(data); });
              return remove;
            },

            call: function (method, args) { return post(method, args); }
          };

          var METHODS = [
            "connect", "disconnect", "getState",
            "startDeviceScan", "stopDeviceScan",
            "getCommMode", "setCommMode",
            "getNetworkSSID", "setNetworkSSID",
            "getNetworkPassword", "setNetworkPassword",
            "getAlertNotification", "setAlertNotification",
            "getVersion", "getSerialNumber", "getDeviceName", "setDeviceName",
            "getModel", "getIPv4", "getMac",
            "getBatterySoc", "getBatterySoh", "getBatteryCycles",
            "factoryReset", "reboot", "performOTA",
            "sendRawCmd", "getHWVersion", "getHWSerialNumber", "bootFirmware",
            "singleTagInventory", "startSyncInventory", "getTagBuffer",
            "startAsyncInventory", "stopAsyncInventory",
            "startEXAsyncInventory", "stopEXAsyncInventory",
            "writeTagEPC", "writeTag", "lockTag", "killTag", "readTagMemoryBank",
            "getAntennaPort", "setAntennaPort",
            "getFreqHopping", "setFreqHopping",
            "getRegion", "setRegion", "getTemperature",
            "getReaderConfiguration", "setReaderConfiguration",
            "getSession", "setSession",
            "getTarget", "setTarget",
            "getRFMode", "setRFMode",
            "getQ", "setQ"
          ];

          METHODS.forEach(function (method) {
            api[method] = function (args) { return post(method, args); };
          });

          window.RFIDReader = api;
          window.dispatchEvent(new Event("rfidreaderready"));
        })();
        """.trimIndent()
}
