package com.bypratham.rfidreaderconnect.webbridge

import com.bypratham.rfidreaderconnect.RFIDReaderDelegate
import com.bypratham.rfidreaderconnect.RFIDTag

/**
 * Fans every `RFIDReaderDelegate` callback out to an ordered list of children.
 *
 * `RFIDReader` accepts only one delegate. When you need more than one observer
 * (e.g. a native ViewModel *and* the web bridge), wrap them and hand the
 * multiplex delegate to the reader.
 */
class MultiplexRFIDReaderDelegate(
    private val delegates: List<RFIDReaderDelegate>,
) : RFIDReaderDelegate {
    override fun rfidReaderDidConnect() {
        delegates.forEach { it.rfidReaderDidConnect() }
    }

    override fun rfidReaderDidBecomeReady() {
        delegates.forEach { it.rfidReaderDidBecomeReady() }
    }

    override fun rfidReaderDidDisconnect() {
        delegates.forEach { it.rfidReaderDidDisconnect() }
    }

    override fun rfidReaderDidReceiveMessage(message: Any) {
        delegates.forEach { it.rfidReaderDidReceiveMessage(message) }
    }

    override fun rfidReaderDidStartScanning() {
        delegates.forEach { it.rfidReaderDidStartScanning() }
    }

    override fun rfidReaderDidStopScanning() {
        delegates.forEach { it.rfidReaderDidStopScanning() }
    }

    override fun rfidReaderDidReadTag(tag: RFIDTag) {
        delegates.forEach { it.rfidReaderDidReadTag(tag) }
    }

    override fun rfidReaderDidEncounteredError(error: Throwable) {
        delegates.forEach { it.rfidReaderDidEncounteredError(error) }
    }

    override fun rfidReaderDidReceiveRawData(data: ByteArray) {
        delegates.forEach { it.rfidReaderDidReceiveRawData(data) }
    }
}
