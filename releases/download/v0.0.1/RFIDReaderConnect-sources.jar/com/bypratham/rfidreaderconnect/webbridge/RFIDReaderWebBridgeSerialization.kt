package com.bypratham.rfidreaderconnect.webbridge

import com.bypratham.rfidreaderconnect.RFIDReaderAntennaPort
import com.bypratham.rfidreaderconnect.RFIDReaderCommMode
import com.bypratham.rfidreaderconnect.RFIDReaderConfiguration
import com.bypratham.rfidreaderconnect.RFIDReaderNotificationType
import com.bypratham.rfidreaderconnect.RFIDReaderQ
import com.bypratham.rfidreaderconnect.RFIDReaderRFMode
import com.bypratham.rfidreaderconnect.RFIDReaderRegion
import com.bypratham.rfidreaderconnect.RFIDReaderSerialNumber
import com.bypratham.rfidreaderconnect.RFIDReaderSession
import com.bypratham.rfidreaderconnect.RFIDReaderTarget
import com.bypratham.rfidreaderconnect.RFIDReaderVersion
import com.bypratham.rfidreaderconnect.RFIDTag
import com.bypratham.rfidreaderconnect.toHex
import org.json.JSONArray
import org.json.JSONObject

/**
 * Converts SDK types into JSON-safe values for the web bridge.
 *
 * The `wireName` mappings preserve the case names used by the iOS bridge
 * (`"ble"`, `"wifiAP"`, `"FCC"`, …) so cross-platform JS callers see the same
 * strings regardless of the underlying Kotlin enum entry name.
 */
internal object RFIDReaderWebBridgeSerialization {
    fun serializeTag(tag: RFIDTag): JSONObject =
        JSONObject().apply {
            put("epc", tag.epc.toHex())
            put("epcLen", tag.epcLen.toInt())
            tag.pc?.let { put("pc", it.toInt()) }
            tag.rssi?.let { put("rssi", it) }
            tag.antennaID?.let { put("antennaID", it.toInt()) }
            tag.frequency?.let { put("frequency", it.toHex()) }
            tag.timestamp?.let { put("timestamp", it.toHex()) }
            tag.phase?.let { put("phase", it.inDegrees().second) }
            tag.tagDataLen?.let { put("tagDataLen", it.toInt()) }
        }

    @Suppress("LongMethod")
    fun serializeMessage(message: Any?): JSONObject {
        return when (message) {
            is RFIDReaderRegion ->
                JSONObject()
                    .put("type", "region")
                    .put("name", regionWireName(message))
                    .put("raw", message.rawValue.toInt())

            is RFIDReaderSession ->
                JSONObject()
                    .put("type", "session")
                    .put("name", sessionWireName(message))
                    .put("raw", message.rawValue.toInt())

            is RFIDReaderTarget ->
                JSONObject().put("type", "target").put("name", targetWireName(message))

            is RFIDReaderQ ->
                when (message) {
                    RFIDReaderQ.DynamicQ -> JSONObject().put("type", "q").put("mode", "dynamic")
                    is RFIDReaderQ.StaticQ ->
                        JSONObject()
                            .put("type", "q")
                            .put("mode", "static")
                            .put("value", message.value.toInt())
                }

            is RFIDReaderRFMode ->
                JSONObject()
                    .put("type", "rfMode")
                    .put("name", rfModeWireName(message))
                    .put("raw", message.rawValue.toInt())

            is RFIDReaderConfiguration ->
                JSONObject()
                    .put("type", "readerConfiguration")
                    .put("name", configurationWireName(message))
                    .put("raw", message.rawValue.toInt())

            is RFIDReaderCommMode ->
                JSONObject()
                    .put("type", "commMode")
                    .put("name", commModeWireName(message))
                    .put("raw", message.rawValue.toInt())

            is RFIDReaderNotificationType ->
                JSONObject()
                    .put("type", "notification")
                    .put("name", notificationWireName(message))
                    .put("raw", message.rawValue.toInt())

            is com.bypratham.rfidreaderconnect.RFIDReaderModel ->
                JSONObject().put("type", "model").put("value", message.rawValue)

            is RFIDReaderVersion ->
                JSONObject()
                    .put("type", "version")
                    .put("bootloaderVersion", message.bootloaderVersion.toHex())
                    .put("hardwareVersion", message.hardwareVersion.toHex())
                    .put("firmwareDate", message.firmwareDate.toHex())
                    .put("firmwareVersion", message.firmwareVersion.toHex())

            is RFIDReaderSerialNumber ->
                JSONObject()
                    .put("type", "serialNumber")
                    .put("year", message.year.toHex())
                    .put("serialNumber", message.serialNumber.toHex())

            is RFIDTag -> {
                val dict = serializeTag(message)
                dict.put("type", "tag")
                dict
            }

            is List<*> -> {
                val arr = JSONArray()
                message.forEach { item ->
                    if (item is RFIDReaderAntennaPort) {
                        arr.put(
                            JSONObject()
                                .put("number", item.number.toInt())
                                .put("readPower", item.readPower.toInt())
                                .put("writePower", item.writePower.toInt()),
                        )
                    } else {
                        arr.put(jsonSafe(item))
                    }
                }
                JSONObject().put("type", "antennaPorts").put("ports", arr)
            }

            is Map<*, *> -> {
                val out = JSONObject().put("type", "info")
                for ((key, value) in message) {
                    if (key is String) {
                        out.put(key, jsonSafe(value))
                    }
                }
                out
            }

            null -> JSONObject().put("type", "unknown").put("description", "null")

            else -> JSONObject().put("type", "unknown").put("description", message.toString())
        }
    }

    private fun jsonSafe(value: Any?): Any {
        return when (value) {
            null -> JSONObject.NULL
            is ByteArray -> value.toHex()
            is UByte -> value.toInt()
            is UShort -> value.toInt()
            is UInt -> value.toLong()
            is Number, is String, is Boolean -> value
            else -> value.toString()
        }
    }

    fun commModeWireName(mode: RFIDReaderCommMode): String =
        when (mode) {
            RFIDReaderCommMode.BLE -> "ble"
            RFIDReaderCommMode.WIFI_AP -> "wifiAP"
            RFIDReaderCommMode.WIFI_STA -> "wifiSTA"
            RFIDReaderCommMode.USB -> "usb"
        }

    fun notificationWireName(value: RFIDReaderNotificationType): String =
        when (value) {
            RFIDReaderNotificationType.NONE -> "none"
            RFIDReaderNotificationType.LED -> "led"
            RFIDReaderNotificationType.BEEP -> "beep"
            RFIDReaderNotificationType.LED_AND_BEEP -> "ledAndBeep"
            RFIDReaderNotificationType.VIBRATE -> "vibrate"
            RFIDReaderNotificationType.LED_AND_VIBRATE -> "ledAndVibrate"
            RFIDReaderNotificationType.BEEP_AND_VIBRATE -> "beepAndVibrate"
            RFIDReaderNotificationType.LED_BEEP_AND_VIBRATE -> "ledBeepAndVibrate"
        }

    fun regionWireName(value: RFIDReaderRegion): String = value.name

    fun sessionWireName(value: RFIDReaderSession): String =
        when (value) {
            RFIDReaderSession.ZERO -> "zero"
            RFIDReaderSession.ONE -> "one"
            RFIDReaderSession.TWO -> "two"
            RFIDReaderSession.THREE -> "three"
        }

    fun targetWireName(value: RFIDReaderTarget): String =
        when (value) {
            RFIDReaderTarget.A -> "a"
            RFIDReaderTarget.B -> "b"
            RFIDReaderTarget.AB -> "ab"
            RFIDReaderTarget.BA -> "ba"
        }

    fun rfModeWireName(value: RFIDReaderRFMode): String =
        when (value) {
            RFIDReaderRFMode.ONE -> "one"
            RFIDReaderRFMode.THREE -> "three"
            RFIDReaderRFMode.FIVE -> "five"
            RFIDReaderRFMode.SEVEN -> "seven"
            RFIDReaderRFMode.ELEVEN -> "eleven"
            RFIDReaderRFMode.TWELVE -> "twelve"
            RFIDReaderRFMode.THIRTEEN -> "thirteen"
            RFIDReaderRFMode.FIFTEEN -> "fifteen"
            RFIDReaderRFMode.ONE_ZERO_THREE -> "oneZeroThree"
            RFIDReaderRFMode.ONE_TWO_ZERO -> "oneTwoZero"
            RFIDReaderRFMode.THREE_FOUR_FIVE -> "threeFourFive"
        }

    fun configurationWireName(value: RFIDReaderConfiguration): String =
        when (value) {
            RFIDReaderConfiguration.USE_ANTENNA_PORT_AS_UNIQUE_IDENTIFIER -> "useAntennaPortAsUniqueIdentifier"
            RFIDReaderConfiguration.RECORD_MAXIMUM_RSSI_VALUE -> "recordMaximumRSSIValue"
            RFIDReaderConfiguration.USE_BANK_DATA_AS_UNIQUE_IDENTIFIER -> "useBankDataAsUniqueIdentifier"
        }
}
