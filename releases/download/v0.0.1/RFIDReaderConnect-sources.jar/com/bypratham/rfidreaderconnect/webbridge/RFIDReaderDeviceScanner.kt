package com.bypratham.rfidreaderconnect.webbridge

import android.annotation.SuppressLint
import android.bluetooth.BluetoothManager
import android.bluetooth.le.ScanCallback
import android.bluetooth.le.ScanResult
import android.content.Context
import android.util.Log
import androidx.annotation.RequiresPermission

/** A device surfaced to the web bridge (e.g. a BLE peripheral). */
data class RFIDReaderDiscoveredDevice(
    val identifier: String,
    val name: String,
)

/**
 * Discovery mechanism plugged into the [RFIDReaderWebBridge]. Implemented by
 * the host app or by [BLEDeviceScanner] when Bluetooth discovery is enough.
 */
interface RFIDReaderDeviceScanner {
    fun startScan(onDevice: (RFIDReaderDiscoveredDevice) -> Unit)

    fun stopScan()
}

/**
 * Default BLE-based scanner using [android.bluetooth.le.BluetoothLeScanner].
 *
 * The host application MUST hold `BLUETOOTH_SCAN` (API 31+) or the legacy
 * `BLUETOOTH_ADMIN` + `ACCESS_FINE_LOCATION` permissions before calling
 * [startScan]; the scanner does not request them.
 */
class BLEDeviceScanner(
    private val context: Context,
) : RFIDReaderDeviceScanner {
    private val tag = "[BLEDeviceScanner]"
    private val bluetoothManager: BluetoothManager? =
        context.getSystemService(Context.BLUETOOTH_SERVICE) as? BluetoothManager

    private var currentCallback: ScanCallback? = null
    private var onDeviceCallback: ((RFIDReaderDiscoveredDevice) -> Unit)? = null

    @SuppressLint("MissingPermission")
    @RequiresPermission("android.permission.BLUETOOTH_SCAN")
    override fun startScan(onDevice: (RFIDReaderDiscoveredDevice) -> Unit) {
        val adapter = bluetoothManager?.adapter
        val scanner = adapter?.bluetoothLeScanner
        if (scanner == null) {
            Log.w(tag, "BluetoothLeScanner unavailable — is Bluetooth enabled?")
            return
        }
        onDeviceCallback = onDevice
        val callback =
            object : ScanCallback() {
                override fun onScanResult(
                    callbackType: Int,
                    result: ScanResult,
                ) {
                    val device = result.device ?: return
                    val name = device.name ?: result.scanRecord?.deviceName ?: "Unknown"
                    onDeviceCallback?.invoke(
                        RFIDReaderDiscoveredDevice(
                            identifier = device.address,
                            name = name,
                        ),
                    )
                }

                override fun onScanFailed(errorCode: Int) {
                    Log.w(tag, "Scan failed: errorCode=$errorCode")
                }
            }
        currentCallback = callback
        scanner.startScan(callback)
    }

    @SuppressLint("MissingPermission")
    @RequiresPermission("android.permission.BLUETOOTH_SCAN")
    override fun stopScan() {
        val adapter = bluetoothManager?.adapter
        val scanner = adapter?.bluetoothLeScanner
        val callback = currentCallback
        if (scanner != null && callback != null) {
            scanner.stopScan(callback)
        }
        currentCallback = null
        onDeviceCallback = null
    }
}
