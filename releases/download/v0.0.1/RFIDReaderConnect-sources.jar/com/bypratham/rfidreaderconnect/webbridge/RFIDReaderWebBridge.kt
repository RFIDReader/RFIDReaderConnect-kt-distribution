package com.bypratham.rfidreaderconnect.webbridge

import android.annotation.SuppressLint
import android.content.Context
import android.os.Handler
import android.os.Looper
import android.util.Log
import android.webkit.JavascriptInterface
import android.webkit.WebView
import androidx.webkit.WebViewCompat
import androidx.webkit.WebViewFeature
import com.bypratham.rfidreaderconnect.RFIDReader
import com.bypratham.rfidreaderconnect.RFIDReaderDelegate
import com.bypratham.rfidreaderconnect.RFIDTag
import com.bypratham.rfidreaderconnect.toHex
import org.json.JSONException
import org.json.JSONObject

/**
 * Bridges an Android [WebView] mini-program to the [RFIDReader] SDK.
 *
 * Usage:
 * ```kotlin
 * val bridge = RFIDReaderWebBridge(
 *     context = appContext,
 *     handlerName = "rfidBridge",
 *     readerProvider = { appState.reader },
 *     onReaderCreated = { appState.reader = it },
 *     deviceScanner = BLEDeviceScanner(appContext),
 * )
 * bridge.installOn(webView)
 * ```
 *
 * From JavaScript (the injected client library is available at
 * `window.RFIDReader`):
 * ```js
 * await RFIDReader.connect({ model: "MARK3-HH7", transport: { type: "ble", identifier: "AA:BB:CC:DD:EE:FF" } })
 * RFIDReader.on("tag", (t) => console.log(t.epc))
 * await RFIDReader.startAsyncInventory()
 * ```
 *
 * If the WebView doesn't support `DOCUMENT_START_SCRIPT`, callers must invoke
 * [injectScript] from their own `WebViewClient.onPageStarted` — the bridge
 * logs a warning in that case.
 */
class RFIDReaderWebBridge
    @JvmOverloads
    constructor(
        private val context: Context,
        val handlerName: String = "rfidBridge",
        private val readerProvider: () -> RFIDReader?,
        private val additionalDelegates: List<RFIDReaderDelegate> = emptyList(),
        private val onReaderCreated: ((RFIDReader) -> Unit)? = null,
        private val deviceScanner: RFIDReaderDeviceScanner? = null,
    ) : RFIDReaderDelegate {
        private val tag = "[RFIDReaderWebBridge]"
        private val mainHandler = Handler(Looper.getMainLooper())

        private var attachedReader: RFIDReader? = null
        private var originalDelegate: RFIDReaderDelegate? = null
        private var webView: WebView? = null

        val reader: RFIDReader? get() = readerProvider()

        @SuppressLint("JavascriptInterface")
        fun installOn(webView: WebView) {
            this.webView = webView
            webView.settings.javaScriptEnabled = true
            webView.removeJavascriptInterface(handlerName)
            webView.addJavascriptInterface(nativeInterface, handlerName)

            if (WebViewFeature.isFeatureSupported(WebViewFeature.DOCUMENT_START_SCRIPT)) {
                WebViewCompat.addDocumentStartJavaScript(
                    webView,
                    RFIDReaderBridgeScript.source(handlerName),
                    setOf("*"),
                )
            } else {
                Log.w(
                    tag,
                    "DOCUMENT_START_SCRIPT unsupported on this WebView. " +
                        "Call bridge.injectScript() from your WebViewClient.onPageStarted / onPageFinished.",
                )
            }
        }

        /** Detach the bridge from the WebView. Does not disconnect the reader. */
        fun uninstall() {
            webView?.removeJavascriptInterface(handlerName)
            detachFromReader()
            webView = null
        }

        /** Injects the JS client library into the current WebView. Only needed when the fallback path is taken. */
        fun injectScript() {
            val view = webView ?: return
            mainHandler.post {
                view.evaluateJavascript(RFIDReaderBridgeScript.source(handlerName), null)
            }
        }

        /** Attaches the bridge to the current shared reader if not already attached. */
        fun attachIfNeeded() {
            val current = readerProvider() ?: return
            if (current === attachedReader) return
            detachFromReader()

            val existing = current.getDelegate()
            originalDelegate = existing
            current.setDelegate(MultiplexRFIDReaderDelegate(listOf(existing, this)))
            attachedReader = current
        }

        private fun detachFromReader() {
            attachedReader?.let { reader -> originalDelegate?.let { reader.setDelegate(it) } }
            attachedReader = null
            originalDelegate = null
        }

        // region JavaScript interface

        private val nativeInterface =
            object {
                @JavascriptInterface
                fun postMessage(json: String) {
                    val body =
                        try {
                            JSONObject(json)
                        } catch (e: JSONException) {
                            Log.w(tag, "Bad JSON from JS: ${e.message}")
                            return
                        }
                    val method = body.optString("method", "")
                    val args = body.optJSONObject("args") ?: JSONObject()
                    val requestId = if (body.isNull("requestId")) null else body.optString("requestId", "").ifEmpty { null }
                    // Dispatch onto the main thread so reader calls are safe from any UI/state assumptions.
                    mainHandler.post {
                        RFIDReaderWebBridgeCommands.dispatch(this@RFIDReaderWebBridge, method, args, requestId)
                    }
                }
            }

        // endregion

        // region Command result helpers

        internal fun resolve(
            requestId: String?,
            result: Any?,
        ) {
            if (requestId == null) return
            val payload =
                JSONObject().apply {
                    put("requestId", requestId)
                    put("ok", true)
                    put("result", result ?: JSONObject.NULL)
                }
            dispatchToJs("__rfidBridgeResolve", payload)
        }

        internal fun reject(
            requestId: String?,
            message: String,
        ) {
            if (requestId == null) return
            val payload =
                JSONObject().apply {
                    put("requestId", requestId)
                    put("ok", false)
                    put("error", message)
                }
            dispatchToJs("__rfidBridgeResolve", payload)
        }

        internal fun emit(
            event: String,
            data: Any?,
        ) {
            val payload =
                JSONObject().apply {
                    put("event", event)
                    put("data", data ?: JSONObject.NULL)
                }
            dispatchToJs("__rfidBridgeEmit", payload)
        }

        private fun dispatchToJs(
            function: String,
            payload: JSONObject,
        ) {
            val js = "window.$function && window.$function(${payload});"
            mainHandler.post { webView?.evaluateJavascript(js, null) }
        }

        // endregion

        // region Connection

        internal fun handleConnect(
            args: JSONObject,
            requestId: String?,
        ) {
            val existing = readerProvider()
            if (existing != null) {
                attachIfNeeded()
                if (existing.isConnected) {
                    emit("connect", JSONObject.NULL)
                    rfidReaderDidBecomeReady()
                } else {
                    existing.connect()
                }
                resolve(requestId, null)
                return
            }

            val model =
                try {
                    RFIDReaderWebBridgeCommands.parseModel(args)
                } catch (e: RFIDBridgeError) {
                    reject(requestId, e.bridgeMessage)
                    return
                }
            val name = Args.optString(args, "name")

            val transportArgs =
                args.optJSONObject("transport") ?: run {
                    reject(requestId, "Missing 'transport' configuration.")
                    return
                }
            val transport =
                try {
                    RFIDReaderWebBridgeCommands.parseTransport(context, transportArgs)
                } catch (e: RFIDBridgeError) {
                    reject(requestId, e.bridgeMessage)
                    return
                } catch (t: Throwable) {
                    reject(requestId, t.message ?: "Invalid transport configuration.")
                    return
                }

            val delegate = MultiplexRFIDReaderDelegate(listOf(this) + additionalDelegates)
            val newReader = RFIDReader(model, name, transport, delegate)
            attachedReader = newReader
            originalDelegate =
                when {
                    additionalDelegates.isEmpty() -> null
                    additionalDelegates.size == 1 -> additionalDelegates.first()
                    else -> MultiplexRFIDReaderDelegate(additionalDelegates)
                }

            mainHandler.post {
                onReaderCreated?.invoke(newReader)
                newReader.connect()
                resolve(requestId, null)
            }
        }

        internal fun handleDisconnect(requestId: String?) {
            attachIfNeeded()
            val reader = readerProvider()
            if (reader == null) {
                resolve(requestId, null)
                return
            }
            mainHandler.post { reader.disconnect() }
            resolve(requestId, null)
        }

        // endregion

        // region Device discovery

        internal fun startDeviceScan(requestId: String?) {
            val scanner = deviceScanner
            if (scanner == null) {
                reject(requestId, "Device scanning is not available on this host.")
                return
            }
            scanner.startScan { device ->
                emit(
                    "deviceFound",
                    JSONObject().put("identifier", device.identifier).put("name", device.name),
                )
            }
            resolve(requestId, null)
        }

        internal fun stopDeviceScan(requestId: String?) {
            deviceScanner?.stopScan()
            resolve(requestId, null)
        }

        // endregion

        // region RFIDReaderDelegate

        override fun rfidReaderDidConnect() {
            emit("connect", JSONObject.NULL)
        }

        override fun rfidReaderDidBecomeReady() {
            val r = reader
            val payload =
                JSONObject().apply {
                    r?.model?.rawValue?.let { put("model", it) }
                    r?.name?.let { put("name", it) }
                    r?.serialNumber?.let { put("serialNumber", it) }
                    r?.version?.let { put("version", it) }
                }
            emit("ready", payload)
        }

        override fun rfidReaderDidDisconnect() {
            emit("disconnect", JSONObject.NULL)
        }

        override fun rfidReaderDidReceiveMessage(message: Any) {
            emit("message", RFIDReaderWebBridgeSerialization.serializeMessage(message))
        }

        override fun rfidReaderDidStartScanning() {
            emit("scanStart", JSONObject.NULL)
        }

        override fun rfidReaderDidStopScanning() {
            emit("scanStop", JSONObject.NULL)
        }

        override fun rfidReaderDidReadTag(tag: RFIDTag) {
            emit("tag", RFIDReaderWebBridgeSerialization.serializeTag(tag))
        }

        override fun rfidReaderDidEncounteredError(error: Throwable) {
            emit("error", JSONObject().put("message", error.message ?: error.toString()))
        }

        override fun rfidReaderDidReceiveRawData(data: ByteArray) {
            emit("raw", data.toHex())
        }

        // endregion
    }
