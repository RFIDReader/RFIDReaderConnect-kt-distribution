package com.bypratham.rfidreaderconnect

import android.os.Handler
import android.os.HandlerThread
import android.os.Looper
import android.util.Log
import com.bypratham.rfidreaderconnect.constants.commandCodeToName
import com.bypratham.rfidreaderconnect.messages.AsyncInventoryParser
import com.bypratham.rfidreaderconnect.messages.AsyncInventoryParserDelegate
import com.bypratham.rfidreaderconnect.messages.Messenger
import com.bypratham.rfidreaderconnect.messages.messageParser
import com.bypratham.rfidreaderconnect.messages.moduleMessageParser
import com.bypratham.rfidreaderconnect.streamingota.StreamingOTAClient
import com.bypratham.rfidreaderconnect.streamingota.StreamingOTAClientDelegate
import com.bypratham.rfidreaderconnect.transport.BLETransport
import com.bypratham.rfidreaderconnect.transport.TransportDelegate
import com.bypratham.rfidreaderconnect.transport.TransportProtocol
import com.bypratham.rfidreaderconnect.transport.TransportType
import com.bypratham.rfidreaderconnect.transport.USBTransport
import com.bypratham.rfidreaderconnect.transport.WiFiTransport
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch

/**
 * Primary SDK entry point. Mirrors the iOS `RFIDReader` class 1:1 in API
 * surface and semantics.
 *
 * Buffer parsing runs on a dedicated `HandlerThread` (`rfid-parsing`) so
 * transport receive callbacks are serialized without blocking BLE / socket
 * threads. All delegate callbacks are dispatched on the Android main thread
 * (parity with iOS `DispatchQueue.main.async`).
 */
class RFIDReader(
    model: RFIDReaderModel,
    val name: String? = null,
    transport: TransportType,
    delegate: RFIDReaderDelegate,
) : RFIDReaderProtocol, TransportDelegate, AsyncInventoryParserDelegate {
    private val tag = "[RFIDReader]"

    private val transport: TransportProtocol
    private var delegate: RFIDReaderDelegate = delegate
    private val asyncInventoryParser: AsyncInventoryParser

    /** Read-only transport configuration, matching the Apple SDK's public state. */
    val transportType: TransportType = transport

    /** Out-of-band response route used by [StreamingOTAClient]. */
    internal var streamingOTAFrameObserver: ((cmd: Int, status: UShort, data: ByteArray) -> Unit)? = null
    internal var streamingOTAErrorObserver: ((error: Throwable) -> Unit)? = null

    private var buffer: ByteArray = ByteArray(0)
    private val parsingThread: HandlerThread =
        HandlerThread("rfid-parsing").apply { start() }
    private val parsingHandler: Handler = Handler(parsingThread.looper)
    private val mainHandler: Handler = Handler(Looper.getMainLooper())

    @Volatile
    private var isProcessingBuffer: Boolean = false

    var model: RFIDReaderModel? = model
        private set

    var serialNumber: String? = null
        private set

    var version: String? = null
        private set

    /** True while the transport reports an active connection. */
    var isConnected: Boolean = false
        private set

    /** True while an asynchronous inventory session is running. */
    var isScanning: Boolean = false
        private set

    private val scope = CoroutineScope(Dispatchers.Default + SupervisorJob())

    init {
        this.asyncInventoryParser = AsyncInventoryParser(this)
        this.transport =
            when (transport) {
                is TransportType.Ble ->
                    BLETransport(
                        context = transport.context,
                        identifier = transport.identifier,
                        timeoutMs = transport.connectionTimeout,
                        maxRetries = transport.maxRetries,
                        retryInterval = transport.retryInterval,
                        delegate = this,
                        debug = transport.debug,
                    )

                is TransportType.WiFi ->
                    WiFiTransport(
                        host = transport.host,
                        httpPort = transport.httpPort,
                        tcpPort = transport.tcpPort,
                        udpPort = transport.udpPort,
                        transportMode = transport.mode,
                        maxRetries = transport.maxRetries,
                        retryInterval = transport.retryInterval,
                        delegate = this,
                        debug = transport.debug,
                    )

                is TransportType.Usb ->
                    USBTransport(
                        context = transport.context,
                        device = transport.device,
                        portName = transport.portName,
                        delegate = this,
                        debug = transport.debug,
                    )
            }
    }

    /** Replaces the current delegate. Useful for wrapping with `MultiplexRFIDReaderDelegate`. */
    fun setDelegate(delegate: RFIDReaderDelegate) {
        this.delegate = delegate
    }

    /** Returns the currently installed delegate. */
    fun getDelegate(): RFIDReaderDelegate = delegate

    override fun connect() = transport.connect()

    override fun disconnect() = transport.disconnect()

    // region Reader functions
    override fun getCommMode() = safeSendData(Messenger.getCommMode)

    override fun setCommMode(commMode: RFIDReaderCommMode) = safeSendData(Messenger.setCommMode(commMode))

    override fun getNetworkSSID() = safeSendData(Messenger.getNetworkSSID)

    override fun setNetworkSSID(ssid: String) = safeSendData(Messenger.setNetworkSSID(ssid))

    override fun getNetworkPassword() = safeSendData(Messenger.getNetworkPassword)

    override fun setNetworkPassword(password: String) = safeSendData(Messenger.setNetworkPassword(password))

    override fun getAlertNotification() = safeSendData(Messenger.getAlertNotificationType)

    override fun setAlertNotification(notificationType: RFIDReaderNotificationType) =
        safeSendData(Messenger.setAlertNotificationType(notificationType))

    override fun getVersion() = safeSendData(Messenger.getVersion)

    override fun getSerialNumber() = safeSendData(Messenger.getSerialNumber)

    override fun getDeviceName() = safeSendData(Messenger.getDeviceName)

    override fun setDeviceName(deviceName: String) = safeSendData(Messenger.setDeviceName(deviceName))

    override fun getModel() = safeSendData(Messenger.getModel)

    override fun getIPv4() = safeSendData(Messenger.getIPv4)

    override fun getMac() = safeSendData(Messenger.getMac)

    override fun getBatterySoc() = safeSendData(Messenger.getBatterySoc)

    override fun getBatterySoh() = safeSendData(Messenger.getBatterySoh)

    override fun getBatteryCycles() = safeSendData(Messenger.getBatteryCycles)

    override fun factoryReset() = safeSendData(Messenger.performFactoryReset)

    override fun reboot() = safeSendData(Messenger.performReboot)

    /** Sends a pre-framed streaming OTA command without appending a module CRC. */
    internal fun sendStreamingOTAFrame(data: ByteArray) {
        transport.sendData(data)
    }

    override fun performOTA(version: String) = safeSendData(Messenger.performOTA(version))

    /**
     * Streams firmware over the active transport. If [sha256] is omitted, the
     * SDK computes it before starting the transfer.
     */
    fun performStreamingOTA(
        imageData: ByteArray,
        sha256: ByteArray? = null,
        version: String,
        delegate: StreamingOTAClientDelegate,
    ): StreamingOTAClient {
        val client = StreamingOTAClient(this)
        client.start(
            imageData = imageData,
            sha256 = sha256 ?: StreamingOTAClient.sha256(imageData),
            version = version,
            delegate = delegate,
        )
        return client
    }
    // endregion

    // region Module functions
    override fun sendRawCmd(
        cmd: ByteArray,
        calculateCRC: Boolean,
    ) = safeSendData(Messenger.sendRawCmd(cmd, calculateCRC))

    override fun getHWVersion() = safeSendData(Messenger.getHWVersion())

    override fun getHWSerialNumber() = safeSendData(Messenger.getHWSerialNumber())

    override fun bootFirmware() = safeSendData(Messenger.bootFirmware())

    override fun singleTagInventory(
        timeout: UShort,
        metadata: List<RFIDReaderTagMetadata>?,
        tagSingulationFlag: RFIDReaderTagSingulationFlag?,
        tagSingulationData: RFIDReaderTagSingulationData?,
    ) = safeSendData(
        Messenger.singleTagInventory(
            timeout = timeout,
            metadata = metadata,
            tsFlag = tagSingulationFlag,
            tsData = tagSingulationData,
        ),
    )

    override fun startSyncInventory() {
        // TODO: parity stub — implement when firmware branch lands
    }

    override fun getTagBuffer() {
        // TODO: parity stub — implement when firmware branch lands
    }

    override fun startAsyncInventory(
        powerSave: Boolean?,
        metadata: List<RFIDReaderTagMetadata>?,
        password: RFIDTagPassword?,
        tsFlag: RFIDReaderTagSingulationFlag?,
        tsData: RFIDReaderTagSingulationData?,
        memoryBank: RFIDTagMemoryBank?,
        readAddress: RFIDTagMemoryAddress?,
        wordCount: UByte?,
    ) {
        safeSendData(
            Messenger.startAsyncInventory(
                powerSave = powerSave,
                metadata = metadata,
                password = password,
                tsFlag = tsFlag,
                tsData = tsData,
                memoryBank = memoryBank,
                readAddress = readAddress,
                wordCount = wordCount,
            ),
        )
        isScanning = true
        dispatchMain { delegate.rfidReaderDidStartScanning() }
    }

    override fun stopAsyncInventory() {
        safeSendData(Messenger.stopAsyncInventory())
        // Fail-safe: if the reader never acknowledges the stop, flip state locally.
        scope.launch {
            delay(1.5)
            if (isScanning) {
                isScanning = false
                dispatchMain { delegate.rfidReaderDidStopScanning() }
            }
        }
    }

    override fun startEXAsyncInventory(metadata: List<RFIDReaderTagMetadata>?) {
        safeSendData(Messenger.startEXAsyncInventory(metadata))
        isScanning = true
        dispatchMain { delegate.rfidReaderDidStartScanning() }
    }

    override fun stopEXAsyncInventory() {
        safeSendData(Messenger.stopEXAsyncInventory())
        scope.launch {
            delay(1.5)
            if (isScanning) {
                isScanning = false
                dispatchMain { delegate.rfidReaderDidStopScanning() }
            }
        }
    }

    override fun writeTagEPC(
        tagEPC: ByteArray,
        timeout: UShort,
        password: RFIDTagPassword?,
        tagSingulationFlag: RFIDReaderTagSingulationFlag?,
        tagSingulationData: RFIDReaderTagSingulationData?,
    ) = safeSendData(
        Messenger.writeTagEPC(
            tagEPC = tagEPC,
            timeout = timeout,
            password = password,
            tsFlag = tagSingulationFlag,
            tsData = tagSingulationData,
        ),
    )

    override fun writeTag(data: ByteArray) {
        // TODO: parity stub — implement when firmware branch lands
    }

    override fun lockTag() {
        // TODO: parity stub — implement when firmware branch lands
    }

    override fun killTag() {
        // TODO: parity stub — implement when firmware branch lands
    }

    override fun readTagMemoryBank(
        timeout: UShort,
        tagSingulationFlag: RFIDReaderTagSingulationFlag?,
        metadata: List<RFIDReaderTagMetadata>?,
        memoryBank: RFIDTagMemoryBank,
        readAddress: RFIDTagMemoryAddress,
        wordCount: UByte,
        password: RFIDTagPassword?,
        tagSingulationData: RFIDReaderTagSingulationData?,
    ): RFIDTag? {
        safeSendData(
            Messenger.readTagMemoryBank(
                timeout = timeout,
                tsFlag = tagSingulationFlag,
                metadata = metadata,
                memoryBank = memoryBank,
                readAddress = readAddress,
                wordCount = wordCount,
                password = password,
                tsData = tagSingulationData,
            ),
        )
        return null
    }

    override fun getAntennaPort() = safeSendData(Messenger.getAntennaPorts())

    override fun setAntennaPort(
        antennaPorts: List<RFIDReaderAntennaPort>,
        permanent: Boolean?,
    ) = safeSendData(Messenger.setAntennaPorts(antennaPorts))

    override fun getFreqHopping() = safeSendData(Messenger.getFreqHopping())

    override fun setFreqHopping(region: RFIDReaderRegion) =
        safeSendData(Messenger.setFreqHopping(frequencyTable[region] ?: IntArray(0)))

    override fun getRegion() = safeSendData(Messenger.getRegion())

    override fun setRegion(
        region: RFIDReaderRegion,
        permanent: Boolean?,
    ) = safeSendData(Messenger.setRegion(region))

    override fun getTemperature() = safeSendData(Messenger.getTemperature())

    override fun getReaderConfiguration(readerConfiguration: RFIDReaderConfiguration) =
        safeSendData(Messenger.getReaderConfiguration(readerConfiguration))

    override fun setReaderConfiguration(
        readerConfiguration: RFIDReaderConfiguration,
        enable: Boolean,
    ) = safeSendData(Messenger.setReaderConfiguration(readerConfiguration, enable))

    override fun getSession() = safeSendData(Messenger.getSession())

    override fun setSession(
        session: RFIDReaderSession,
        permanent: Boolean?,
    ) = safeSendData(Messenger.setSession(session))

    override fun getTarget() = safeSendData(Messenger.getTarget())

    override fun setTarget(
        target: RFIDReaderTarget,
        permanent: Boolean?,
    ) = safeSendData(Messenger.setTarget(target))

    override fun getRFMode() = safeSendData(Messenger.getRFMode())

    override fun setRFMode(
        mode: RFIDReaderRFMode,
        permanent: Boolean?,
    ) = safeSendData(Messenger.setRFMode(mode))

    override fun getQ() = safeSendData(Messenger.getQ())

    override fun setQ(
        q: RFIDReaderQ?,
        permanent: Boolean?,
    ) = safeSendData(Messenger.setQ(q))
    // endregion

    private fun safeSendData(data: ByteArray) {
        try {
            transport.sendData(data)
        } catch (t: Throwable) {
            dispatchMain { delegate.rfidReaderDidEncounteredError(t) }
        }
    }

    private fun dispatchMain(block: () -> Unit) {
        mainHandler.post(block)
    }

    // region TransportDelegate
    override fun transportDidConnect() {
        isConnected = true
        dispatchMain { delegate.rfidReaderDidConnect() }
    }

    override fun transportDidBecomeReady() {
        scope.launch {
            delay(0.2)
            getVersion()
            delay(0.1)
            getModel()
            delay(0.1)
            getSerialNumber()
            delay(0.01)
            getHWVersion()
            delay(0.01)
            getHWSerialNumber()
            delay(0.01)
            dispatchMain { delegate.rfidReaderDidBecomeReady() }
        }
    }

    override fun transportDidDisconnect() {
        isConnected = false
        isScanning = false
        streamingOTAErrorObserver?.invoke(
            RFIDReaderError.TransportNotReady("Transport disconnected during streaming OTA."),
        )
        dispatchMain { delegate.rfidReaderDidDisconnect() }
    }

    override fun transportDidWriteMessage() {
        // Intentionally empty — matches iOS.
    }

    override fun transportDidReceiveMessage(data: ByteArray?) {
        parsingHandler.post {
            if (data == null || data.isEmpty()) {
                Log.w(tag, "Transport: Received invalid data")
                return@post
            }
            dispatchMain { delegate.rfidReaderDidReceiveRawData(data) }
            buffer += data
            processBuffer()
        }
    }

    override fun transportDidEncounteredError(error: Throwable) {
        streamingOTAErrorObserver?.invoke(error)
        dispatchMain { delegate.rfidReaderDidEncounteredError(error) }
    }
    // endregion

    private fun processBuffer() {
        if (isProcessingBuffer) return
        isProcessingBuffer = true
        try {
            while (true) {
                if (buffer.size < 5) return

                val header = buffer[0].toInt() and 0xFF
                if (header != 0x00 && header != 0xFF) {
                    buffer = buffer.copyOfRange(1, buffer.size)
                    continue
                }
                val dataLen = buffer[1].toInt() and 0xFF
                val crcLength = if (header == 0xFF) 2 else 0
                val totalMessageLength = 5 + dataLen + crcLength
                if (buffer.size < totalMessageLength) {
                    Log.d(tag, "Waiting for more data. Buffer length: ${buffer.size}, Required: $totalMessageLength")
                    return
                }

                var frameBuffer = buffer.copyOfRange(0, 5 + dataLen)
                if (header == 0xFF) {
                    val receivedCrc =
                        (((buffer[5 + dataLen].toInt() and 0xFF) shl 8) or (buffer[5 + dataLen + 1].toInt() and 0xFF))
                            .toUShort()
                    val calculatedCrc = calcCRC(frameBuffer)
                    if (receivedCrc != calculatedCrc) {
                        Log.w(
                            tag,
                            "CRC mismatch. FrameBuffer: ${dataAsHex(frameBuffer)} " +
                                "Received: %04X, Calculated: %04X. Skipping byte.".format(
                                    receivedCrc.toInt(),
                                    calculatedCrc.toInt(),
                                ),
                        )
                        buffer = buffer.copyOfRange(1, buffer.size)
                        continue
                    }
                    frameBuffer = frameBuffer + byteArrayOf(buffer[5 + dataLen], buffer[5 + dataLen + 1])
                } else {
                    frameBuffer = frameBuffer + byteArrayOf(0x00, 0x00)
                }

                processFrameBuffer(frameBuffer)
                buffer = buffer.copyOfRange(totalMessageLength, buffer.size)
            }
        } finally {
            isProcessingBuffer = false
        }
    }

    private fun processFrameBuffer(frameBuffer: ByteArray) {
        val header = frameBuffer[0].toInt() and 0xFF
        val cmd = (frameBuffer[2].toInt() and 0xFF).toUByte()
        val statusCode =
            (((frameBuffer[3].toInt() and 0xFF) shl 8) or (frameBuffer[4].toInt() and 0xFF))
                .toUShort()

        if (
            header == 0x00 &&
            cmd.toInt() in Messenger.STREAMING_OTA_CMD_BEGIN..Messenger.STREAMING_OTA_CMD_ABORT
        ) {
            val observer = streamingOTAFrameObserver
            if (observer != null) {
                val dataLength = frameBuffer[1].toInt() and 0xFF
                val payload =
                    if (dataLength > 0 && frameBuffer.size >= 5 + dataLength) {
                        frameBuffer.copyOfRange(5, 5 + dataLength)
                    } else {
                        ByteArray(0)
                    }
                observer(cmd.toInt(), statusCode, payload)
                return
            }
        }

        if (header == 0x00) {
            val parser = messageParser[cmd]
            if (parser != null) {
                val result = parser(frameBuffer)
                if (result != null) {
                    dispatchMain {
                        delegate.rfidReaderDidReceiveMessage(result)
                        if (result is RFIDReaderModel && model != result) {
                            Log.w(
                                tag,
                                "Model Mismatch Detected!. Please connect the reader with correct model. Disconnecting...",
                            )
                            disconnect()
                        } else if (result is Map<*, *>) {
                            when (result.keys.firstOrNull()) {
                                "serial_number" -> serialNumber = result["serial_number"] as? String
                                "version" -> version = result["version"] as? String
                                else -> Unit
                            }
                        }
                    }
                } else {
                    Log.w(tag, "Failed to parse data for command: %02X".format(cmd.toInt()))
                }
            } else {
                Log.w(tag, "No parser found for command: %02X".format(cmd.toInt()))
            }
        } else if (header == 0xFF && cmd.toInt() != 0xAA) {
            val parser = moduleMessageParser[cmd]
            if (parser != null) {
                if (statusCode.toInt() != 0x0000) {
                    val errorDescription = statusCodes[statusCode] ?: "Unknown error"
                    val error =
                        RFIDReaderError.ReaderError(
                            cmd = commandCodeToName[cmd] ?: "Unknown",
                            description = errorDescription,
                        )
                    dispatchMain { delegate.rfidReaderDidEncounteredError(error) }
                    return
                }
                val result = parser(frameBuffer)
                if (result != null) {
                    dispatchMain { delegate.rfidReaderDidReceiveMessage(result) }
                } else {
                    Log.w(tag, "Failed to parse data for command: %02X".format(cmd.toInt()))
                }
            } else {
                Log.w(tag, "No parser found for command: %02X".format(cmd.toInt()))
            }
        } else if (header == 0xFF && cmd.toInt() == 0xAA) {
            asyncInventoryParser.parse(frameBuffer)
        } else {
            Log.w(tag, "No parser found for command: %02X".format(cmd.toInt()))
        }
    }

    // region AsyncInventoryParserDelegate
    override fun asyncInventoryParserDidReceiveStartAsyncInventory() {
        isScanning = true
        dispatchMain { delegate.rfidReaderDidStartScanning() }
    }

    override fun asyncInventoryParserDidReadTag(tag: RFIDTag) {
        dispatchMain { delegate.rfidReaderDidReadTag(tag) }
    }

    override fun asyncInventoryParserDidReceiveHearbeatPacket() {
        if (!isScanning) {
            isScanning = true
            dispatchMain { delegate.rfidReaderDidStartScanning() }
        }
    }

    override fun asyncInventoryParserDidReceiveStopAsyncInventory() {
        isScanning = false
        dispatchMain { delegate.rfidReaderDidStopScanning() }
    }

    override fun asyncInventoryParserDidEncounteredError(error: Throwable) {
        dispatchMain { delegate.rfidReaderDidEncounteredError(error) }
    }
    // endregion
}
