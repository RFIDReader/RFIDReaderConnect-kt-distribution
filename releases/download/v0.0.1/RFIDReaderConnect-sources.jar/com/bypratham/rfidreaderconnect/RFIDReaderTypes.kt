package com.bypratham.rfidreaderconnect

/**
 * All model / enum / data classes shared across the SDK. Mirrors iOS
 * `RFIDReaderTypes.swift` 1:1 in terms of raw values and constructor shapes.
 */

/** Supported Mark3 reader models. Raw value is the identifier string returned by the reader. */
enum class RFIDReaderModel(val rawValue: String) {
    MARK3_HH7("MARK3-HH7"),
    MARK3_HH5("MARK3-HH5"),
    MARK3_TT7("MARK3-TT7"),
    MARK3_TT5("MARK3-TT5"),
    MARK3_TT3("MARK3-TT3"),
    ;

    companion object {
        @JvmStatic
        fun fromRaw(value: String): RFIDReaderModel? = values().firstOrNull { it.rawValue == value }
    }
}

/** Communication mode advertised by the reader. */
enum class RFIDReaderCommMode(val rawValue: UByte) {
    BLE(0x00u),
    WIFI_AP(0x01u),
    WIFI_STA(0x02u),
    USB(0x03u),
    ;

    companion object {
        @JvmStatic
        fun fromRaw(value: UByte): RFIDReaderCommMode? = values().firstOrNull { it.rawValue == value }
    }
}

/** Reader-side notification mode when a tag is scanned. */
enum class RFIDReaderNotificationType(val rawValue: UByte) {
    NONE(0x00u),
    LED(0x01u),
    BEEP(0x02u),
    LED_AND_BEEP(0x03u),
    VIBRATE(0x04u),
    LED_AND_VIBRATE(0x05u),
    BEEP_AND_VIBRATE(0x06u),
    LED_BEEP_AND_VIBRATE(0x07u),
    ;

    companion object {
        @JvmStatic
        fun fromRaw(value: UByte): RFIDReaderNotificationType? = values().firstOrNull { it.rawValue == value }
    }
}

/** Serial baud rate options supported by the module. */
enum class RFIDReaderBaudRate(val rawValue: Int) {
    BASE(115_200),
    MAX(921_600),
}

/** Firmware / hardware / bootloader version block returned by `getVersion` / `bootFirmware`. */
class RFIDReaderVersion(
    val bootloaderVersion: ByteArray,
    val hardwareVersion: ByteArray,
    val firmwareDate: ByteArray,
    val firmwareVersion: ByteArray,
) {
    override fun toString(): String =
        "<RFIDReaderVersion> bootloaderVersion: ${dataAsHex(bootloaderVersion)}, " +
            "hardwareVersion: ${dataAsHex(hardwareVersion)}, " +
            "firmwareDate: ${dataAsHex(firmwareDate)}, " +
            "firmwareVersion: ${dataAsHex(firmwareVersion)}"
}

/** Serial number block returned by `getHWSerialNumber`. */
class RFIDReaderSerialNumber(
    val year: ByteArray,
    val serialNumber: ByteArray,
) {
    override fun toString(): String =
        "<RFIDReaderSerialNumber> year: ${dataAsHex(year)}, " +
            "serialNumber: ${dataAsHex(serialNumber)}"
}

/** Region / regulatory profile the reader is operating under. */
enum class RFIDReaderRegion(val rawValue: UByte) {
    /** North America */
    FCC(0x01u),

    /** China1 */
    CH(0x06u),

    /** Europe */
    CE_LOW(0x08u),

    /** Korea */
    KR(0x09u),

    /** Japan */
    JP(0x0Bu),

    CE_HIGH(0x0Cu),

    /** Hong Kong */
    HK(0x0Du),

    /** Taiwan */
    TW(0x0Eu),

    /** Malaysia */
    MY(0x0Fu),

    /** South Africa */
    S_AF(0x10u),

    /** Brazil */
    BR(0x11u),

    /** Thailand */
    TH(0x12u),

    /** Singapore */
    SG(0x13u),

    /** Australia */
    AU(0x14u),

    /** India */
    IN(0x04u),

    /** Uruguay */
    UY(0x16u),

    /** Vietnam */
    VD(0x17u),

    /** Israel */
    IL(0x18u),

    /** Philippines */
    PH(0x19u),

    /** Indonesia */
    ID(0x1Au),

    /** New Zealand */
    NZ(0x1Bu),

    /** Peru */
    PE(0x1Cu),

    /** Russia */
    RU(0x1Du),

    FULL(0xFFu),
    ;

    companion object {
        @JvmStatic
        fun fromRaw(value: UByte): RFIDReaderRegion? = values().firstOrNull { it.rawValue == value }
    }
}

/** Frequency plans (kHz) for each region. Copied verbatim from iOS `RFIDReaderTypes.swift`. */
val frequencyTable: Map<RFIDReaderRegion, IntArray> =
    mapOf(
        RFIDReaderRegion.FCC to
            intArrayOf(
                915250, 902750, 927250, 915750, 903250, 926750, 908250, 918250, 923250, 905250,
                916250, 911250, 921250, 913250, 906250, 914250, 909250, 919250, 924250, 904250,
                917250, 912250, 922250, 920250, 907250, 914750, 909750, 919750, 924750, 904750,
                912750, 907750, 917750, 922750, 910250, 925250, 910750, 920750, 925750, 905750,
                913750, 908750, 918750, 923750, 903750, 916750, 911750, 921750, 926250, 906750,
            ),
        RFIDReaderRegion.CH to
            intArrayOf(
                922125, 920625, 924375, 922375, 920875, 924125, 922625, 921125, 923875, 921875,
                923625, 922875, 921375, 923125, 921625, 923375,
            ),
        RFIDReaderRegion.CE_LOW to intArrayOf(865700, 866300, 866900, 867500),
        RFIDReaderRegion.JP to intArrayOf(916800, 918000, 919200, 920400),
        RFIDReaderRegion.KR to intArrayOf(917300, 917900, 918500, 919100, 919700, 920300),
        RFIDReaderRegion.HK to
            intArrayOf(
                920250, 920750, 921250, 921750, 922250, 922750, 923250, 923750, 924250, 924750,
            ),
        RFIDReaderRegion.TW to
            intArrayOf(
                920750, 921250, 921750, 922250, 922750, 923250, 923750, 924250, 924750, 925250,
                925750, 926250, 926750, 927250,
            ),
        RFIDReaderRegion.MY to
            intArrayOf(
                919250, 919750, 920250, 920750, 921250, 921750, 922250, 922750,
            ),
        RFIDReaderRegion.S_AF to
            intArrayOf(
                915600, 915800, 916000, 916200, 916400, 916600, 916800, 917000, 917200, 917400,
                917600, 917800, 918000, 918200, 918400, 918600, 918800,
            ),
        RFIDReaderRegion.BR to
            intArrayOf(
                902750, 903250, 903750, 904250, 904750, 905250, 905750, 906250, 906750, 907250,
                907750, 908250, 908750, 909250, 909750, 910250, 910750, 911250, 911750, 912250,
                912750, 913250, 913750, 914250, 914750, 915250, 915750, 916250, 916750, 917250,
                917750, 918250, 918750, 919250, 919750, 920250, 920750, 921250, 921750, 922250,
                922750, 923250, 923750, 924250, 924750, 925250, 925750, 926250, 926750, 927250,
            ),
        RFIDReaderRegion.TH to
            intArrayOf(
                920250, 920750, 921250, 921750, 922250, 922750, 923250, 923750, 924250, 924750,
            ),
        RFIDReaderRegion.SG to
            intArrayOf(
                920250, 920750, 921250, 921750, 922250, 922750, 923250, 923750, 924250, 924750,
            ),
        RFIDReaderRegion.AU to
            intArrayOf(
                920250, 920750, 921250, 921750, 922250, 922750, 923250, 923750, 924250, 924750,
            ),
        RFIDReaderRegion.IN to intArrayOf(865100, 865700, 866300, 866900),
        RFIDReaderRegion.UY to
            intArrayOf(
                916250, 916750, 917250, 917750, 918250, 918750, 919250, 919750, 920250, 920750,
                921250, 921750, 922250, 922750, 923250, 923750, 924250, 924750, 925250, 925750,
                926250, 926750, 927250,
            ),
        RFIDReaderRegion.VD to
            intArrayOf(
                918750, 919250, 919750, 920250, 920750, 921250, 921750, 922250,
            ),
        RFIDReaderRegion.IL to intArrayOf(916250),
        RFIDReaderRegion.PH to intArrayOf(918250, 918750, 919250, 919750),
        RFIDReaderRegion.ID to intArrayOf(917250, 920750, 921250, 921750),
        RFIDReaderRegion.NZ to
            intArrayOf(
                922250, 922750, 923250, 923750, 924250, 924750, 925250, 925750, 926250, 926750,
            ),
        RFIDReaderRegion.PE to
            intArrayOf(
                916250, 916750, 917250, 917750, 918250, 918750, 919250, 919750, 920250, 920750,
                921250, 921750, 922250, 922750, 923250, 923750, 924250, 924750, 925250, 925750,
                926250, 926750, 927250,
            ),
        RFIDReaderRegion.RU to intArrayOf(916200, 917400, 918600, 919800),
        RFIDReaderRegion.FULL to
            intArrayOf(
                910000, 860000, 960000, 900000, 870000, 940000, 920000, 890000, 950000, 930000,
                880000,
            ),
    )

/** Reader-wide configuration flags. */
enum class RFIDReaderConfiguration(val rawValue: UByte) {
    USE_ANTENNA_PORT_AS_UNIQUE_IDENTIFIER(0x00u),
    RECORD_MAXIMUM_RSSI_VALUE(0x06u),
    USE_BANK_DATA_AS_UNIQUE_IDENTIFIER(0x08u),
    ;

    companion object {
        @JvmStatic
        fun fromRaw(value: UByte): RFIDReaderConfiguration? = values().firstOrNull { it.rawValue == value }
    }
}

/** GEN2 inventory session identifier. */
enum class RFIDReaderSession(val rawValue: UByte) {
    ZERO(0x00u),
    ONE(0x01u),
    TWO(0x02u),
    THREE(0x03u),
    ;

    companion object {
        @JvmStatic
        fun fromRaw(value: UByte): RFIDReaderSession? = values().firstOrNull { it.rawValue == value }
    }
}

/** GEN2 inventory target flag. */
enum class RFIDReaderTarget { A, B, AB, BA }

/** Optional filter block used by inventory / read / write commands. */
class RFIDReaderTagSingulationData(
    /** Offset within the bank, in bits. Presence depends on the Select-Option bits. */
    val selectAddress: ByteArray? = null,
    /**
     * Length of the compared data in bits. Typically one byte; two bytes when the
     * Select-Option Bits = 0x20.
     */
    val selectDataLength: ByteArray,
    /** The data to be compared with the specified tag data in the bank. */
    val selectData: ByteArray,
) {
    init {
        require(selectAddress == null || selectAddress.size == 4) { "selectAddress.size must be 4" }
        require(selectDataLength.size <= 2) { "selectDataLength.size must be <= 2" }
    }

    override fun toString(): String =
        "<RFIDReaderTagSingulationData> selectAddress: ${dataAsHex(selectAddress ?: ByteArray(0))}, " +
            "selectDataLength: ${dataAsHex(selectDataLength)}, " +
            "selectData: ${dataAsHex(selectData)}"
}

/** Selection / filtering flag used together with [RFIDReaderTagSingulationData]. */
enum class RFIDReaderTagSingulationFlag(val rawValue: UByte) {
    NONE(0x00u),
    FILTER_EPC(0x01u),
    FILTER_TID(0x02u),
    FILTER_USER_BANK(0x03u),
    FILTER_EPC_CONTENT(0x04u),
    FILTER_MULTIPLE_TAGS(0x07u),
    SET_INVERSION_FLAG(0x08u),
    FILTER_MORE_TAGS(0x20u),
    ;

    companion object {
        @JvmStatic
        fun fromRaw(value: UByte): RFIDReaderTagSingulationFlag? = values().firstOrNull { it.rawValue == value }
    }
}

/** Bit flags selecting which metadata fields should accompany each inventoried tag. */
enum class RFIDReaderTagMetadata(val rawValue: UShort) {
    NONE(0x0000u),
    RETURN_READ_COUNT(0x0001u),
    RETURN_RSSI(0x0002u),
    RETURN_ANTENNA_ID(0x0004u),
    RETURN_FREQUENCY(0x0008u),
    RETURN_TIMESTAMP(0x0010u),
    RETURN_PHASE_VALUE(0x0020u),
    RETURN_DATA_LEN(0x0080u),
    ;

    companion object {
        @JvmStatic
        fun fromRaw(value: UShort): RFIDReaderTagMetadata? = values().firstOrNull { it.rawValue == value }
    }
}

/** Antenna port configuration entry. */
class RFIDReaderAntennaPort(
    val number: UByte,
    val readPower: UShort,
    val writePower: UShort,
) {
    override fun toString(): String =
        "<RFIDReaderAntennaPort> number: %02X".format(number.toInt()) +
            ", readPower: %02X".format(readPower.toInt()) +
            ", writePower: %02X".format(writePower.toInt())
}

/** GEN2 RF mode ID. */
enum class RFIDReaderRFMode(val rawValue: UByte) {
    ONE(0x65u),
    THREE(0x67u),
    FIVE(0x69u),
    SEVEN(0x6Bu),
    ELEVEN(0x6Fu),
    TWELVE(0x70u),
    THIRTEEN(0x71u),
    FIFTEEN(0x73u),
    ONE_ZERO_THREE(0xCBu),
    ONE_TWO_ZERO(0xDCu),
    THREE_FOUR_FIVE(0x2Du),
    ;

    companion object {
        @JvmStatic
        fun fromRaw(value: UByte): RFIDReaderRFMode? = values().firstOrNull { it.rawValue == value }
    }
}

/** Q value used for GEN2 inventory rounds. */
sealed class RFIDReaderQ {
    object DynamicQ : RFIDReaderQ()

    data class StaticQ(val value: UByte) : RFIDReaderQ()
}

/** 4-byte password used to unlock a tag's access / kill / write operation. */
typealias RFIDTagPassword = UInt

/** 4-byte memory address inside a tag memory bank. */
typealias RFIDTagMemoryAddress = UInt

/** Memory bank identifier used when reading / writing a tag. */
enum class RFIDTagMemoryBank(val rawValue: UByte) {
    RESERVED(0x00u),
    EPC(0x01u),
    TID(0x02u),
    USER(0x03u),
    ;

    companion object {
        @JvmStatic
        fun fromRaw(value: UByte): RFIDTagMemoryBank? = values().firstOrNull { it.rawValue == value }
    }
}

/**
 * Two-byte phase value returned by the reader. Use [inDegrees] to convert to a
 * usable angle range.
 */
class RFIDTagPhase(val value: UShort) {
    /**
     * Converts the raw phase value into degrees. When [isSingleTagInventory] is
     * true, returns (startPhaseDegrees, endPhaseDegrees). Otherwise returns
     * (-1, phaseInDegrees).
     */
    @JvmOverloads
    fun inDegrees(isSingleTagInventory: Boolean = false): Pair<Int, Int> {
        val raw = value.toInt() and 0xFFFF
        return if (isSingleTagInventory) {
            val startPhaseHighByte = ((raw ushr 8) and 0xFF).toDouble()
            val endPhaseLowByte = (raw and 0xFF).toDouble()
            val startPhaseDegrees = (startPhaseHighByte * 360.0 / 256.0).toInt()
            val endPhaseDegrees = (endPhaseLowByte * 360.0 / 256.0).toInt()
            Pair(startPhaseDegrees, endPhaseDegrees)
        } else {
            val validPhaseValue = (raw and 0x0FFF).toDouble()
            val phaseInDegrees = (validPhaseValue * 360.0 / 4096.0).toInt()
            Pair(-1, phaseInDegrees)
        }
    }
}

/** An RFID tag response — one is produced per inventoried tag. */
class RFIDTag(
    /** RSSI stored as `Int?` because iOS reinterprets the raw UInt8 as Int8. */
    val rssi: Int?,
    val antennaID: UByte?,
    val frequency: ByteArray?,
    val timestamp: ByteArray?,
    val phase: RFIDTagPhase?,
    val tagDataLen: UShort?,
    val epcLen: UByte,
    val pc: UShort?,
    val epc: ByteArray,
) {
    override fun toString(): String =
        "<RFIDTag> rssi: $rssi, antennaID: $antennaID, " +
            "frequency: ${frequency?.let { dataAsHex(it) }}, " +
            "timestamp: ${timestamp?.let { dataAsHex(it) }}, " +
            "phase: ${phase?.value}, tagDataLen: $tagDataLen, " +
            "epcLen: $epcLen, pc: $pc, epc: ${dataAsHex(epc)}"
}
